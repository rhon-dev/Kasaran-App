# Kumpas iOS personal-test prototype

**Status: source prototype prepared; iPhone build and runtime verification are blocked by the missing full Xcode installation. No installable IPA has been produced.**

This is a separate project for testing on the owner's iPhone 14 Pro. The Android thesis project is not changed or replaced. The iOS port is not an approved thesis platform, validated assessment instrument or participant-study release.

## Included implementation

- The copied five-tab Flutter interface, with an explicit `iOS TEST` banner.
- A native `UiKitView` camera surface instead of the Android view.
- AVFoundation front-camera capture, portrait orientation, mirrored preview and unmirrored model frames.
- MediaPipe pose and hand landmark extraction on a serial background queue.
- The unchanged historical 50-sign TFLite classifier, label map, detector task assets and gold-standard binary.
- The 30-frame, 258-feature normalization and DTW-based corrective feedback port.
- Prototype-only JSON persistence for sessions, attempt history, assessments, unique exports and scoped deletion.
- Explicit errors instead of mock recognition when camera permission, model initialization or storage fails.
- Unsupported benchmark errors; this prototype does not fabricate Android benchmark reports.

The native iOS implementation is present in source. UIKit, AVFoundation, MediaPipe, TensorFlow Lite and Flutter integration have **not** been compiled together with an iOS SDK or exercised on a phone.

## Verified on this Mac

The parent recovered files after three workers lost their final responses to provider rate limits. A failed response did not mean that no files were written. The current files were inspected and the following checks were freshly executed:

- Flutter analysis: no issues.
- Flutter test suite: **78 tests passed**, including mocked platform-view and camera-error behavior. These are not installed iPhone tests.
- Swift math host executable: **8 behavioral groups passed**.
- Swift store host executable: **12 behavioral groups passed**, including persistence/reopen, retries, malformed/nonfinite data, exports, unrelated sentinels and dangling managed export links.
- Historical feedback parity: **2 fixtures passed** against the expected reports.
- Foundation-native checks passed for camera/attempt revocation, persistence fencing, listener replacement, finite little-endian Float32 parsing, actual gold decoding and actual resource-bundle loading.
- Native Swift syntax parsing passed. Syntax parsing is not iOS SDK typechecking or linking.

Actual command logs are under `evidence/parent/`. Earlier failed runs remain preserved. The parent fixed the demonstrated `NSObject.load()` name collision and dangling-export-link cleanup failure, then reran the relevant checks.

The five bundled assets are independently bound to the existing protected hashes in `evidence/parent/assets.json`. The pose task was read from the resident existing release APK because the original checkout copy had a macOS DATALESS flag; its bytes matched the independent expected hash. No cloud hydration, model conversion or retraining was used.

## Current build blocker

`flutter build ios --debug --no-codesign` exited 1. The verbose log shows:

```text
xcrun: error: unable to find utility "xcodebuild", not a developer tool or in PATH
Application not configured for iOS
```

The generated iOS project exists. Flutter cannot obtain its Xcode build settings through the selected Command Line Tools installation. `xcode-select -p` reports `/Library/Developer/CommandLineTools`; full Xcode was not found in the checked application locations.

Disk availability was about 14 GiB at the latest check. Check the actual requirements for the Xcode version you install before downloading it. No files were deleted to make space, no license was accepted on your behalf and no paid membership was purchased.

## Finish setup and test on iPhone 14 Pro

These are **next steps, not operations already performed**. Do not uninstall or clear an existing app with useful data. This prototype has its own bundle identity and separate storage.

1. Install full Xcode from Apple and open it. Review any license before accepting it. Install the required iOS development components. Optional simulator runtimes are not required for a physical-phone-only test.
2. Select the installed Xcode developer directory. For the usual installation path:

   ```sh
   sudo xcode-select --switch /Applications/Xcode.app/Contents/Developer
   xcodebuild -version
   ```

   Stop if `xcodebuild -version` still fails. Do not run the later steps against an incomplete toolchain.
3. Restore Flutter dependencies and resolve the native pods:

   ```sh
   cd /Users/ahronjanl.rafaelahron.0804icloudcom/Documents/Thesis/kumpas-ios-demo
   flutter pub get
   cd ios
   pod install
   open Runner.xcworkspace
   ```

   Open the **workspace**, not just `Runner.xcodeproj`. Native dependencies are currently specified as MediaPipeTasksVision `0.10.21` and TensorFlowLiteSwift `2.14.0`. Their combined resolution/linking and the model's runtime compatibility remain unverified until this step and the build succeed. Keep the generated `Podfile.lock` after successful resolution.
4. In Xcode, select the Runner target and configure Signing & Capabilities with your own development team. A free Personal Team may be used for personal-device testing under Apple's applicable restrictions. Do not enter Apple credentials in chat. Flutter previously discovered an existing local development identity; that observation does not prove a valid iPhone provisioning profile.
5. Connect and unlock the iPhone. Review and accept the phone's computer-trust prompt if appropriate. Enable Developer Mode in the iPhone's Privacy & Security settings and complete the requested restart/confirmation.
6. Select the iPhone 14 Pro as the run destination, then build and run. Stop on any compile, pod, signing or model-loading error; retain the exact error and fix it rather than substituting simulated output.
7. Grant camera access when the prototype requests it. Use the sign library to select a sign, open practice and start an attempt. A complete capture uses 30 samples and normally spans approximately four seconds; slower processing may extend it.
8. Verify that a real native result reaches the Flutter feedback sheet and appears in history after leaving and reopening the screen. Check camera denial/retry, background/resume and navigation during capture. Confirm that right/left-hand guidance agrees with the actual camera view before treating the prompts as useful.

## Runtime limitations and privacy

- No iPhone startup, camera orientation, anatomical handedness, accuracy, frame rate, thermal behavior or model-runtime compatibility is certified yet.
- Split pose/hand landmarkers are used, not a full Holistic pipeline. Matching dimensions does not establish detector equivalence.
- The existing model/reference and expert-validation limitations are inherited. Host parity does not prove linguistic correctness or learning benefit.
- No raw video is recorded or uploaded. Capture is processed on-device; results are stored locally.
- The store is prototype JSON in the app's Application Support directory, not the Android SQLite schema. Its exports identify the prototype format and must not be passed off as validated research exports.
- Export currently returns a private container path. A phone-native share sheet is not implemented; do not assume the path is visible in Files merely because file sharing is enabled.
- Backup exclusion is requested on a best-effort basis. Scoped deletion is not forensic erasure and cannot remove copies transferred elsewhere.
- Research benchmark qualification is unsupported. Assessment forms are retained for personal UI testing, not participant collection or approved outcome scoring.

## Host check commands

Run from the project root. All store checks use isolated temporary data, never installed participant stores.

```sh
flutter analyze
flutter test --reporter expanded

swiftc -D HOST_CHECK \
  ios/KumpasNative/Sources/Core/FeatureNormalizer.swift \
  ios/KumpasNative/Sources/Core/FeedbackEngine.swift \
  Tests/KumpasCoreTests/MathTests.swift \
  -o evidence/parent/math-host-check
./evidence/parent/math-host-check

swiftc -D STORE_HOST_TEST \
  ios/KumpasNative/Sources/Core/PrototypeStore.swift \
  Tests/KumpasCoreTests/StoreTests.swift \
  -o evidence/parent/store-host-check
TMPDIR=/Users/ahronjanl.rafaelahron.0804icloudcom/.hermes/cache/scratch/ \
  ./evidence/parent/store-host-check

python3 evidence/parent/run_native_checks.py
```

The host checker uses fresh scratch directories and no camera. Its output paths are local evidence records; preserve earlier runs before rerunning. The Swift package remains available for Xcode/XCTest use after the full toolchain is installed; standalone host executables were used here because XCTest was unavailable in the current CLT setup.

## Primary API references used during implementation

- Flutter iOS setup: https://docs.flutter.dev/platform-integration/ios/setup
- MediaPipe pose task for iOS: https://ai.google.dev/edge/mediapipe/solutions/vision/pose_landmarker/ios
- MediaPipe hand task for iOS: https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker/ios
- LiteRT iOS quickstart: https://ai.google.dev/edge/litert/ios/quickstart
- TensorFlow Swift pod source metadata: https://raw.githubusercontent.com/tensorflow/tensorflow/v2.17.0/tensorflow/lite/swift/TensorFlowLiteSwift.podspec (the file declares pod version 2.14.0; the Git tag is not the pod version).

Local copied headers and official sample excerpts used to check signatures are retained under `evidence/native/`. They are not proof that the unresolved pod combination builds.
