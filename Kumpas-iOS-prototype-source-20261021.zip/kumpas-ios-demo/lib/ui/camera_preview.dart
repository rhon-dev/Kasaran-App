import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Native camera surface for the separate personal-test prototype.
/// Unsupported hosts never simulate a camera or recognition result.
class PrototypeCameraPreview extends StatelessWidget {
  const PrototypeCameraPreview({super.key});

  @override
  Widget build(BuildContext context) {
    if (defaultTargetPlatform == TargetPlatform.iOS && !kIsWeb) {
      return const UiKitView(
        viewType: 'kumpas/camera_preview',
        creationParamsCodec: StandardMessageCodec(),
        creationParams: <String, dynamic>{'prototype': true},
      );
    }
    return const ColoredBox(
      color: Color(0xff111827),
      child: Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Text('Camera requires the iOS test build.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white)),
        ),
      ),
    );
  }
}
