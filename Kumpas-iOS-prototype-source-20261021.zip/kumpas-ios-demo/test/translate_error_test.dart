import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kumpas_ios_demo/ui/translate_screen.dart';
import 'package:kumpas_ios_demo/ui/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('kumpas/predictions');

  testWidgets('camera failure replaces stale recognition and permits retry', (tester) async {
    final messenger = TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(channel, (_) async => null);
    addTearDown(() => messenger.setMockMethodCallHandler(channel, null));
    await tester.binding.setSurfaceSize(const Size(800, 1000));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(MaterialApp(theme: KumpasTheme.light(), home: const Scaffold(body: TranslateScreen())));
    await tester.pump();
    Future<void> event(Map<String, dynamic> data) async {
      await messenger.handlePlatformMessage(
        channel.name,
        const StandardMethodCodec().encodeSuccessEnvelope(jsonEncode(data)),
        (_) {},
      );
      await tester.pump();
    }
    await event({'state': 'prediction', 'label': 'HELLO'});
    expect(find.text('HELLO'), findsOneWidget);
    await event({'state': 'camera_error', 'reason': 'Camera permission denied.'});
    expect(find.text('Camera permission denied.'), findsOneWidget);
    expect(find.text('HELLO'), findsNothing);
    expect(find.text('Simulan ang Pagtuklas ng Senyas'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  });
}
