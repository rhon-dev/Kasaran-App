import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kumpas_ios_demo/ui/camera_preview.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() {
    debugDefaultTargetPlatformOverride = null;
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(SystemChannels.platform_views, null);
  });

  testWidgets('iOS selects native camera view, not AndroidView', (tester) async {
    final calls = <MethodCall>[];
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(SystemChannels.platform_views, (call) async {
          calls.add(call);
          return null;
        });
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: SizedBox(width: 300, height: 400,
        child: PrototypeCameraPreview())),
    ));
    await tester.pump();
    expect(find.byType(UiKitView), findsOneWidget);
    expect(find.byType(AndroidView), findsNothing);
    final view = tester.widget<UiKitView>(find.byType(UiKitView));
    expect(view.viewType, 'kumpas/camera_preview');
    expect(calls.any((c) => c.method == 'create'), isTrue);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  }, variant: TargetPlatformVariant({TargetPlatform.iOS}));

  testWidgets('unsupported host never substitutes fake camera results', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: PrototypeCameraPreview()),
    ));
    expect(find.byType(UiKitView), findsNothing);
    expect(find.byType(AndroidView), findsNothing);
    expect(find.text('Camera requires the iOS test build.'), findsOneWidget);
  }, variant: TargetPlatformVariant({TargetPlatform.linux}));
}
