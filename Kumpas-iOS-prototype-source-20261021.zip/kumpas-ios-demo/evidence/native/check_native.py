#!/usr/bin/env python3
"""Host-only native gate/assets checks and Swift syntax parse. NOT an iOS build."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import plistlib
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
NATIVE = ROOT / 'ios/KumpasNative/Sources/Native'
EVIDENCE = ROOT / 'evidence/native'
ASSETS = ROOT / 'ios/KumpasNative/Assets'
log = [f'Host checks at {datetime.datetime.now().astimezone().isoformat()}',
       'Scope: Foundation-only production gate/asset code and syntax parse; no iOS SDK typecheck, pods, camera or inference.']

def run(command):
    log.append('$ ' + ' '.join(map(str, command)))
    p = subprocess.run(list(map(str, command)), text=True, capture_output=True)
    log.extend([p.stdout, p.stderr, f'EXIT: {p.returncode}'])
    print(p.stdout, p.stderr, end='')
    if p.returncode:
        raise RuntimeError(f'Command failed with exit {p.returncode}')

try:
    run(['swiftc', '--version'])
    run(['swiftc', '-frontend', '-parse', *sorted(NATIVE.glob('*.swift'))])
    with tempfile.TemporaryDirectory(prefix='kumpas-native-check-', dir=os.environ['TMPDIR']) as directory:
        work = Path(directory)
        bundle = work / 'KumpasModels.bundle'
        bundle.mkdir()
        (bundle / 'Info.plist').write_bytes(plistlib.dumps({
            'CFBundleIdentifier': 'org.kumpas.host-check.models', 'CFBundlePackageType': 'BNDL',
            'CFBundleName': 'KumpasModels', 'CFBundleVersion': '1'}))
        for name in ['label_map.json', 'gold_standards.bin']:
            shutil.copyfile(ASSETS / name, bundle / name)
        executable = work / 'native-host-check'
        run(['swiftc', NATIVE / 'NativeLifecycleGate.swift', NATIVE / 'NativeAssets.swift',
             EVIDENCE / 'main.swift', '-o', executable])
        run([executable, ASSETS / 'gold_standards.bin', '--load-bundle'])
    manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(NATIVE.glob('*.swift'))}
    (EVIDENCE / 'native-source-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
    log.append('PASS. Native UIKit/AVFoundation/Flutter/MediaPipe/TFLite runtime still UNVERIFIED.')
finally:
    (EVIDENCE / 'host-checks.txt').write_text('\n'.join(log) + '\n')
