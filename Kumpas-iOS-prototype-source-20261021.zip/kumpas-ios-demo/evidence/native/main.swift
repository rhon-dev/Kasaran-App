import Foundation
let gate = NativeLifecycleGate()
let old = gate.claimCamera()
assert(gate.isCurrent(old))
let attempt = gate.beginAttempt(camera: old)!
assert(gate.canDeliver(camera: old, revision: attempt.revision))
let replacement = gate.claimCamera()
assert(!gate.isCurrent(old))
assert(!gate.canDeliver(camera: old, revision: attempt.revision))
assert(!gate.releaseCamera(old))
assert(gate.isCurrent(replacement))
let second = gate.beginAttempt(camera: replacement)!
assert(!gate.cancelAttempt(id: UUID().uuidString))
assert(gate.canDeliver(camera: replacement, revision: second.revision))
assert(gate.cancelAttempt(id: second.id))
assert(!gate.canDeliver(camera: replacement, revision: second.revision))
assert(gate.releaseCamera(replacement))
assert(!gate.isCurrent(replacement))
let listener = gate.listenerRevision()
gate.changeListener()
assert(gate.listenerRevision() != listener)
let final = gate.claimCamera()
gate.shutdown()
assert(!gate.isCurrent(final))
assert(!gate.isCurrent(gate.claimCamera()))
print("PASS: replacement ownership, stale disposal, attempt identity, cancellation event fence, listener revision, shutdown")
let persistenceGate = NativeLifecycleGate()
let camera = persistenceGate.claimCamera()
let capture = persistenceGate.beginAttempt(camera: camera)!
var writes = 0
let saved = persistenceGate.ifCurrent(camera: camera, revision: capture.revision) { writes += 1; return true }
assert(saved == true && writes == 1)
persistenceGate.cancelAttempt(id: capture.id)
let stale = persistenceGate.ifCurrent(camera: camera, revision: capture.revision) { writes += 1; return true }
assert(stale == nil && writes == 1)
print("PASS: terminal persistence fence rejects stale writes")
let decoded = try NativeAssets.floats(Data([0x00, 0x00, 0x80, 0x3f, 0x00, 0x00, 0x00, 0xc0]), count: 2)
assert(decoded == [1, -2])
do { _ = try NativeAssets.floats(Data([0]), count: 1); fatalError("accepted truncated float") } catch { }
do { _ = try NativeAssets.floats(Data([0, 0, 0x80, 0x7f]), count: 1); fatalError("accepted infinity") } catch { }
if CommandLine.arguments.count > 1 {
    let gold = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
    let values = try NativeAssets.floats(gold, count: 50 * 30 * 258)
    assert(values.contains { $0 != 0 })
    print("PASS: actual gold file decodes to \(values.count) finite little-endian Float32 values")
}
if CommandLine.arguments.contains("--load-bundle") {
    let assets = try NativeAssets.loadAssets()
    assert(assets.labels.count == 50 && assets.gold.count == 50)
    assert(assets.gold.allSatisfy { $0.count == 30 && $0.allSatisfy { $0.count == 258 } })
    print("PASS: actual label map and gold resolved from KumpasModels.bundle")
}
print("PASS: Float32 endian decoding, truncated bytes and non-finite rejection")
