import Foundation

private struct ExpectedItem: Decodable {
    let dimension: String
    let hand: String
    let severity: Double
}
private struct FixtureCase: Decodable {
    let learner: [[Float]]
    let gold: [[Float]]
    let targetLabel: String
    let expectedOverall: Double
    let expectedItems: [ExpectedItem]
}

@main private enum FixtureChecks {
    static func main() throws {
        var checked = 0
        for filename in CommandLine.arguments.dropFirst() {
            let fixture = try JSONDecoder().decode(FixtureCase.self, from: Data(contentsOf: URL(fileURLWithPath: filename)))
            let report = try FeedbackEngine.compare(learner: fixture.learner, gold: fixture.gold, targetLabel: fixture.targetLabel)
            guard abs(report.overallMatch - fixture.expectedOverall) <= 0.002,
                  report.items.count == fixture.expectedItems.count else {
                throw NSError(domain: "FixtureChecks", code: 1)
            }
            for (actual, expected) in zip(report.items, fixture.expectedItems) {
                guard actual.dimension == expected.dimension, actual.hand == expected.hand,
                      abs(actual.severity - expected.severity) <= 0.002 else {
                    throw NSError(domain: "FixtureChecks", code: 2)
                }
            }
            checked += 1
            print("PASS historical fixture \(fixture.targetLabel): match=\(report.overallMatch), items=\(report.items.count)")
        }
        guard checked == 2 else { throw NSError(domain: "FixtureChecks", code: 3) }
        print("2/2 historical fixture parity checks passed. No detector or classifier inference.")
    }
}
