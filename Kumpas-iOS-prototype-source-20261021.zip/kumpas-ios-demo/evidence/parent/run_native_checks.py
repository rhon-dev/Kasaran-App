"""Recover native host checks without overwriting failed worker evidence."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import os
import plistlib
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
NATIVE = ROOT/'ios/KumpasNative/Sources/Native'
OUT = ROOT/'evidence/parent'
SCRATCH = Path('/Users/ahronjanl.rafaelahron.0804icloudcom/.hermes/cache/scratch')
log = [datetime.now().astimezone().isoformat(), 'Host Foundation checks and native syntax parse only; NOT an iOS SDK build.']

def run(args):
    result = subprocess.run(list(map(str,args)),text=True,capture_output=True,timeout=120)
    log.extend(['$ '+' '.join(map(str,args)),result.stdout,result.stderr,'EXIT '+str(result.returncode)])
    print(result.stdout, result.stderr)
    if result.returncode:
        raise RuntimeError('CHECK_FAILED')

try:
    run(['swiftc','-frontend','-parse',*sorted(NATIVE.glob('*.swift')),ROOT/'ios/Runner/AppDelegate.swift'])
    with tempfile.TemporaryDirectory(prefix='kumpas-ios-native-',dir=SCRATCH) as temp:
        work=Path(temp)
        bundle=work/'KumpasModels.bundle';bundle.mkdir()
        (bundle/'Info.plist').write_bytes(plistlib.dumps({'CFBundleIdentifier':'com.kumpas.prototype.host.models','CFBundlePackageType':'BNDL','CFBundleName':'KumpasModels','CFBundleVersion':'1'}))
        for name in ['label_map.json','gold_standards.bin']:
            shutil.copyfile(ROOT/'ios/KumpasNative/Assets'/name,bundle/name)
        exe=work/'native-check'
        run(['swiftc',NATIVE/'NativeLifecycleGate.swift',NATIVE/'NativeAssets.swift',ROOT/'evidence/native/main.swift','-o',exe])
        run([exe,ROOT/'ios/KumpasNative/Assets/gold_standards.bin','--load-bundle'])
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(NATIVE.glob('*.swift'))}
    (OUT/'native-current-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
finally:
    (OUT/'native-recovery-green.log').write_text('\n'.join(log)+'\n')
