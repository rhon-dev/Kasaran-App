"""Verify the recovered prototype and create a source-only handoff archive."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import struct
import zipfile

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'evidence/parent'
sha=lambda b:hashlib.sha256(b).hexdigest()
original=json.loads((OUT/'original-snapshot.json').read_text())
preservation=[]
for path,expected in original.items():
    p=Path(path)
    assert not p.stat().st_flags&0x40000000, 'ORIGINAL_NOT_RESIDENT'
    assert sha(p.read_bytes())==expected,'ORIGINAL_CHANGED'
    preservation.append(path)
assets=json.loads((OUT/'assets.json').read_text())
for name,rec in assets.items():
    assert sha((ROOT/'ios/KumpasNative/Assets'/name).read_bytes())==rec['sha256'],'ASSET_CHANGED'
# Verify fixture adaptation against the actual source JSON and unchanged copied gold.
provenance=json.loads((ROOT/'evidence/math/fixture-provenance.json').read_text())
gold=(ROOT/'ios/KumpasNative/Assets/gold_standards.bin').read_bytes()
for rec in provenance['fixtures']:
    p=Path(rec['source'])
    assert not p.stat().st_flags&0x40000000
    b=p.read_bytes();assert sha(b)==rec['sourceSHA256']
    assert sha(gold)==rec['goldSHA256']
    src=json.loads(b)
    name='real-correct.json' if src['target_class']==3 else 'real-handshape.json'
    fixture=json.loads((ROOT/'evidence/math'/name).read_text())
    assert fixture['learner']==src['attempt']
    assert fixture['targetLabel']==src['target_label']
    assert fixture['expectedOverall']==src['expected_overall_match']
    assert fixture['expectedItems']==src['expected_items']
    start=src['target_class']*30*258*4
    values=struct.unpack('<'+str(30*258)+'f',gold[start:start+30*258*4])
    assert fixture['gold']==[list(values[t*258:(t+1)*258]) for t in range(30)]
flutter=(OUT/'flutter-tests-recovered.log').read_text()
match=re.search(r'\+(\d+): All tests passed!',flutter)
assert match and int(match.group(1))==78
assert 'No issues found!' in (OUT/'flutter-analysis-recovered.log').read_text()
assert '8 cases; 0 failures' in (OUT/'math-host-recovered.log').read_text()
assert 'Store host checks: 12/12 passed' in (OUT/'store-host-fixed.log').read_text()
native=(OUT/'native-recovery-green.log').read_text()
assert native.count('PASS:')==5
assert '2/2 historical fixture parity checks passed' in (OUT/'fixture-parity.log').read_text()
build=(OUT/'ios-build-verbose.log').read_text()
assert 'unable to find utility "xcodebuild"' in build
source_paths=[]
for folder in ['lib','test','Tests','ios/KumpasNative/Sources']:
    source_paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in {'.swift','.dart'})
source_paths += [ROOT/'Package.swift',ROOT/'ios/Podfile',ROOT/'ios/KumpasNative/KumpasNative.podspec',ROOT/'ios/Runner/AppDelegate.swift',ROOT/'ios/Runner/Info.plist',ROOT/'ios/Runner.xcodeproj/project.pbxproj',ROOT/'ios/Flutter/Debug.xcconfig',ROOT/'ios/Flutter/Release.xcconfig']
verification={
    'at':datetime.now().astimezone().isoformat(),
    'status':'HOST_CHECKED_SOURCE_PROTOTYPE_IOS_BUILD_BLOCKED',
    'flutter_tests':78,'swift_math_behavior_groups':8,'swift_store_behavior_groups':12,
    'native_foundation_check_groups':5,'historical_feedback_fixture_checks':2,
    'analysis':'No issues found',
    'native_swift_syntax_parse':'PASS_NOT_IOS_TYPECHECK',
    'ios_build':{'exit':1,'blocker':'xcrun cannot find xcodebuild; selected toolchain is CommandLineTools','ipa_produced':False,'device_tested':False},
    'original_copied_files_rehashed_unchanged':len(preservation),
    'assets':assets,
    'source_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted(set(source_paths))},
    'bounds':['No device or simulator operation','No model conversion or retraining','No original Android source edit','No iOS linking/signing/runtime acceptance','No participant-study authorization'],
    'repairs':['Renamed NativeAssets.load to loadAssets to avoid NSObject.load ambiguity','Managed dangling export links are deleted without following targets'],
    'logs':['flutter-tests-recovered.log','flutter-analysis-recovered.log','math-host-recovered.log','store-host-fixed.log','native-recovery-green.log','fixture-parity.log','ios-build-verbose.log']
}
ver=OUT/'verification-20261021.json'
blob=(json.dumps(verification,indent=2)+'\n').encode()
with ver.open('xb') as f:f.write(blob)
assert ver.read_bytes()==blob
allowed={'.swift','.dart','.yaml','.lock','.md','.json','.plist','.pbxproj','.xcconfig','.xcworkspacedata','.xcscheme','.xcsettings','.storyboard','.h','.m','.podspec','.png','.task','.tflite','.bin','.py','.log','.txt'}
exclude={'.dart_tool','.build','.idea','build','Pods','.symlinks','ephemeral'}
entries=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or p.is_symlink():continue
    rel=p.relative_to(ROOT)
    if any(part in exclude for part in rel.parts):continue
    if p.name=='Generated.xcconfig' or p.name in {'flutter_export_environment.sh'}:continue
    if p.suffix not in allowed and p.name not in {'Podfile','.gitignore','.metadata','pubspec.lock'}:continue
    entries.append((p,rel))
archive=ROOT.parent/'Kumpas-iOS-prototype-source-20261021.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,rel in entries:z.write(p,str(Path('kumpas-ios-demo')/rel))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(entries)
    assert z.read('kumpas-ios-demo/evidence/parent/verification-20261021.json')==blob
    for name,rec in assets.items():
        assert sha(z.read('kumpas-ios-demo/ios/KumpasNative/Assets/'+name))==rec['sha256']
archive_manifest={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'entries':len(entries),'verification_sha256':sha(blob),'scope':'SOURCE_ONLY_NOT_INSTALLABLE_IPA'}
with (OUT/'source-archive-20261021.json').open('x') as f:json.dump(archive_manifest,f,indent=2);f.write('\n')
print(json.dumps({'verification':str(ver),'archive':archive_manifest,'preserved_original_files':len(preservation)},indent=2))
