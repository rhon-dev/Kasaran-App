# Kumpas iOS personal-test prototype

## Approved scope

The owner requested an iPhone 14 Pro build and selected real camera capture, sign recognition and corrective feedback. This is a separate prototype at `../kumpas-ios-demo`, not an amendment or acceptance of the Android-only thesis deliverable. Do not modify the Android repository, deploy a different model, train, use participant stores or install anything on a phone without a later explicit installation step.

## Design

Reuse a copied Flutter UI. Replace its Android camera widget with a platform-aware camera widget. Implement a native Swift bridge using AVFoundation, MediaPipe pose and hand landmarkers, and the existing unchanged TFLite classifier and reference assets. Port the existing normalization and feedback calculations without changing their thresholds or language. Use a separate local prototype JSON store; benchmark/research qualification is not supplied by this port.

Native dependency source must follow the official Google iOS task and LiteRT documentation. Keep inference in a serial background queue, deliver UI events on the main queue, cancel pending attempts when a camera view is displaced or suspended, and prevent stale camera callbacks from reaching a replacement view. No recording or cloud transmission of video.

## Shared interfaces

All Swift implementation files are under `ios/KumpasNative/Sources`. CocoaPods compiles them into module `KumpasNative`. A dependency-free Swift package compiles only `Sources/Core` into module `KumpasCore` for host checks.

Math interfaces:

```swift
public enum FeatureNormalizer {
    public static func normalize(_ features: [Float], poseSeen: Bool) throws -> [Float]
}
public struct FeedbackItem: Codable {
    public let dimension: String
    public let severity: Double
    public let hand: String
    public let prompt: String
}
public struct FeedbackReport {
    public let targetLabel: String
    public let overallMatch: Double
    public let items: [FeedbackItem]
}
public enum FeedbackEngine {
    public static func compare(learner: [[Float]], gold: [[Float]], targetLabel: String) throws -> FeedbackReport
}
```

Store interface (all methods may throw; native bridge owns serialization):

```swift
public final class PrototypeStore {
    public init(directory: URL) throws
    public func participantID() throws -> String
    public func startSession() throws -> String
    public func endSession() throws
    public func activeSession() throws -> String?
    public func appendAttempt(_ payload: [String: Any]) throws
    public func history() throws -> [[String: Any]]
    public func saveAssessment(type: String, responses: String) throws
    public func assessments() throws -> [[String: Any]]
    public func exportData() throws -> String
    public func clearAllData() throws
}
```

Native Flutter registration: `public final class KumpasPlugin: NSObject, FlutterPlugin`, with `public static func register(with registrar: FlutterPluginRegistrar)`. Register method channel `kumpas/control`, event channel `kumpas/predictions` and view type `kumpas/camera_preview`. Match the copied Dart JSON keys and string-vs-object encoding exactly. Benchmark methods return an explicit unsupported error, not fabricated measurements.

## Execution plan

1. Scaffold an isolated Flutter iOS project; copy the UI and bind asset hashes. Preserve the complete original Android checkout.
2. Write and execute failing host checks before implementing each Swift math/storage behavior. Verify normalization, gold identity, altered/missing hand cases, persistence/reopen, export and scoped deletion. Preserve command logs.
3. Implement the Swift bridge, serial AVFoundation capture, MediaPipe extraction and TFLite invocation using official API signatures. Denied permission and initialization failures must be visible, not hidden by mock predictions.
4. Add Flutter camera widget tests for iOS and Android platform selection and unsupported platforms. Run copied Flutter tests and analysis. Label mocked tests as mocked.
5. Run host checks and verify exact protected asset hashes. Attempt a real iOS build only if the required SDK is available. Do not equate parse checks or host checks with an iOS build.
6. Deliver the source package, executed test results and exact next steps. Full Xcode is not currently available in checked application locations; selected developer tools are CommandLineTools. Signing identity discovered by Flutter is not proof of a usable iPhone provisioning profile. Do not install Xcode, accept licenses, delete files for space, connect to a phone or charge for membership automatically.

## Acceptance boundaries

An installable app requires a successful iOS build, resolved native pods, signing and actual iPhone execution. When Xcode blocks those steps, report the source prototype as prepared but not installable or device-verified. Host tests cannot certify camera orientation, handedness, model compatibility, latency, feedback validity or iPhone runtime behavior.
