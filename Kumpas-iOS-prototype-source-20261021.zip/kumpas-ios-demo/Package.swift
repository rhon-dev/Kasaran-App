// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "KumpasCore",
    platforms: [.macOS(.v13), .iOS(.v15)],
    products: [.library(name: "KumpasCore", targets: ["KumpasCore"])],
    targets: [
        .target(name: "KumpasCore", path: "ios/KumpasNative/Sources/Core"),
        .testTarget(name: "KumpasCoreTests", dependencies: ["KumpasCore"], path: "Tests/KumpasCoreTests")
    ]
)
