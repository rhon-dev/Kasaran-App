import Foundation

public struct FeedbackItem: Codable {
    public let dimension: String
    public let severity: Double
    public let hand: String
    public let prompt: String

    public init(dimension: String, severity: Double, hand: String, prompt: String) {
        self.dimension = dimension; self.severity = severity; self.hand = hand; self.prompt = prompt
    }
}

public struct FeedbackReport {
    public let targetLabel: String
    public let overallMatch: Double
    public let items: [FeedbackItem]

    public init(targetLabel: String, overallMatch: Double, items: [FeedbackItem]) {
        self.targetLabel = targetLabel; self.overallMatch = overallMatch; self.items = items
    }
}

/// Direct Double-precision port of Android FeedbackEngine.kt (Float input).
public enum FeedbackEngine {
    private static func wrist(_ seq: [[Float]], _ t: Int) -> [Double] {
        [60, 61, 62, 64, 65, 66].map { Double(seq[t][$0]) }
    }

    private static func norm(_ a: [Double]) -> Double {
        var sum = 0.0
        for v in a { sum += v * v }
        return sqrt(sum)
    }

    // Diagonal, up, left; first wins on ties, matching Kotlin/np.argmin.
    static func dtwPath(_ a: [[Double]], _ b: [[Double]]) -> [(Int, Int)] {
        let n = a.count, m = b.count
        var acc = [[Double]](repeating: [Double](repeating: .infinity, count: m + 1), count: n + 1)
        acc[0][0] = 0
        for i in 1...n { for j in 1...m {
            let diff = zip(a[i - 1], b[j - 1]).map { $0 - $1 }
            acc[i][j] = norm(diff) + min(acc[i - 1][j], acc[i][j - 1], acc[i - 1][j - 1])
        } }
        var path: [(Int, Int)] = []
        var i = n, j = m
        while i > 0 && j > 0 {
            path.append((i - 1, j - 1))
            let diag = acc[i - 1][j - 1], up = acc[i - 1][j], left = acc[i][j - 1]
            if diag <= up && diag <= left { i -= 1; j -= 1 }
            else if up <= left { i -= 1 }
            else { j -= 1 }
        }
        return path.reversed()
    }

    // Kotlin Math.round uses floor(x + 0.5), not banker's rounding.
    static func round3(_ value: Double) -> Double { floor(value * 1000 + 0.5) / 1000 }

    private static func motion(_ learner: [[Float]], _ gold: [[Float]], _ path: [(Int, Int)]) -> (Double, String, String) {
        var error = 0.0
        var mean = [Double](repeating: 0, count: 6)
        for (i, j) in path {
            let diff = zip(wrist(learner, i), wrist(gold, j)).map { $0 - $1 }
            error += norm(diff)
            for k in 0..<6 { mean[k] += diff[k] }
        }
        error /= Double(path.count)
        for k in 0..<6 { mean[k] /= Double(path.count) }
        let hand = norm(Array(mean[3..<6])) >= norm(Array(mean[0..<3])) ? "right" : "left"
        let d = hand == "right" ? Array(mean[3..<6]) : Array(mean[0..<3])
        var dirs: [String] = []
        if abs(d[0]) > 0.05 { dirs.append(d[0] > 0 ? "left" : "right") }
        if abs(d[1]) > 0.05 { dirs.append(d[1] > 0 ? "higher" : "lower") }
        let direction = dirs.isEmpty ? "closer to the model path" : dirs.joined(separator: " and ")
        return (min(error / 0.8, 1), hand, direction)
    }

    private static func point(_ seq: [[Float]], _ t: Int, _ base: Int, _ i: Int) -> [Double] {
        let start = base + i * 3
        return (0..<3).map { Double(seq[t][start + $0]) }
    }

    private static func present(_ seq: [[Float]], _ t: Int, _ base: Int) -> Bool {
        seq[t][base..<(base + 63)].contains { $0 != 0 }
    }

    private static func handshape(_ learner: [[Float]], _ gold: [[Float]], _ path: [(Int, Int)], _ base: Int) -> (Double, [String]) {
        let pairs = path.filter { present(learner, $0.0, base) && present(gold, $0.1, base) }
        if pairs.isEmpty {
            let goldUses = gold.indices.contains { present(gold, $0, base) }
            let learnerUses = learner.indices.contains { present(learner, $0, base) }
            return goldUses && !learnerUses ? (1, ["hand not detected"]) : (0, [])
        }
        let fingers = ["thumb", "index", "middle", "ring", "pinky"]
        var errors = [Double](repeating: 0, count: 5)
        for finger in 0..<5 {
            var error = 0.0
            for (i, j) in pairs {
                let lw = point(learner, i, base, 0), gw = point(gold, j, base, 0)
                var fe = 0.0
                for id in (1 + finger * 4)...(4 + finger * 4) {
                    let lp = point(learner, i, base, id), gp = point(gold, j, base, id)
                    let diff = (0..<3).map { (lp[$0] - lw[$0]) - (gp[$0] - gw[$0]) }
                    fe += norm(diff)
                }
                error += fe / 4
            }
            errors[finger] = error / Double(pairs.count)
        }
        let worst = (0..<5).sorted { errors[$0] == errors[$1] ? $0 < $1 : errors[$0] > errors[$1] }
        let score = min(errors[worst[0]] / 0.30, 1)
        let names = worst.filter { errors[$0] > 0.6 * errors[worst[0]] }.prefix(2).map { fingers[$0] }
        return (score, names)
    }

    private static func orientation(_ learner: [[Float]], _ gold: [[Float]], _ path: [(Int, Int)], _ base: Int) -> Double {
        let pairs = path.filter { present(learner, $0.0, base) && present(gold, $0.1, base) }
        if pairs.isEmpty { return 0 }
        func normal(_ seq: [[Float]], _ t: Int) -> [Double] {
            let w = point(seq, t, base, 0), im = point(seq, t, base, 5), pm = point(seq, t, base, 17)
            let v1 = (0..<3).map { im[$0] - w[$0] }, v2 = (0..<3).map { pm[$0] - w[$0] }
            let n = [v1[1] * v2[2] - v1[2] * v2[1],
                     v1[2] * v2[0] - v1[0] * v2[2],
                     v1[0] * v2[1] - v1[1] * v2[0]]
            let length = norm(n) + 1e-8
            return n.map { $0 / length }
        }
        var sum = 0.0
        for (i, j) in pairs {
            let a = normal(learner, i), b = normal(gold, j)
            let dot = min(max(a[0] * b[0] + a[1] * b[1] + a[2] * b[2], -1), 1)
            sum += acos(dot) * 180 / Double.pi
        }
        return min(sum / Double(pairs.count) / 90, 1)
    }

    private static func timing(_ path: [(Int, Int)]) -> (Double, String) {
        var li = 0.0, gi = 0.0
        for k in 1..<path.count {
            let gStep = path[k].1 - path[k - 1].1
            if gStep > 0 { li += Double(path[k].0 - path[k - 1].0); gi += Double(gStep) }
        }
        if li == 0 || gi == 0 { return (1, "faster") }
        let ratio = li / gi
        return (min(abs(log(ratio) / log(2)), 1), ratio > 1 ? "slower" : "faster")
    }

    public static func compare(learner: [[Float]], gold: [[Float]], targetLabel: String) throws -> FeedbackReport {
        for (name, seq) in [("learner", learner), ("gold", gold)] {
            guard seq.count == 30, seq.allSatisfy({ $0.count == 258 && $0.allSatisfy({ $0.isFinite }) }) else {
                throw NSError(domain: "KumpasMath", code: 3, userInfo: [NSLocalizedDescriptionKey: "Expected \(name) sequence of 30 × 258 finite features"])
            }
        }
        let path = dtwPath((0..<learner.count).map { wrist(learner, $0) }, (0..<gold.count).map { wrist(gold, $0) })
        var items: [FeedbackItem] = []
        let (tScore, tempo) = timing(path)
        if tScore > 0.30 {
            let ending = tempo == "faster" ? "take your time." : "keep the movement flowing."
            items.append(FeedbackItem(dimension: "timing", severity: round3(tScore), hand: "both", prompt: "Your sign is \(tempo) than the model — \(ending)"))
        }
        let (score, hand, direction) = motion(learner, gold, path)
        if score > 0.25 {
            items.append(FeedbackItem(dimension: "motion", severity: round3(score), hand: hand, prompt: "Move your \(hand) hand \(direction)."))
        }
        for (hand, base) in [("left", 132), ("right", 195)] {
            let (hScore, worst) = handshape(learner, gold, path, base)
            if hScore > 0.22 {
                let prompt: String
                if worst == ["hand not detected"] {
                    prompt = "This sign uses your \(hand) hand — keep it visible to the camera."
                } else {
                    let plural = worst.count > 1 ? "s" : ""
                    prompt = "Check your \(hand)-hand shape — adjust your \(worst.joined(separator: " and ")) finger\(plural)."
                }
                items.append(FeedbackItem(dimension: "handshape", severity: round3(hScore), hand: hand, prompt: prompt))
            }
            let oScore = orientation(learner, gold, path, base)
            if oScore > 0.25 {
                items.append(FeedbackItem(dimension: "orientation", severity: round3(oScore), hand: hand, prompt: "Rotate your \(hand) palm to match the model orientation."))
            }
        }
        // Explicit index fallback retains insertion order for equal rounded severity.
        items = items.enumerated().sorted {
            $0.element.severity == $1.element.severity ? $0.offset < $1.offset : $0.element.severity > $1.element.severity
        }.map { $0.element }
        let mean = items.isEmpty ? 0 : items.reduce(0) { $0 + $1.severity } / Double(items.count)
        return FeedbackReport(targetLabel: targetLabel, overallMatch: round3(1 - mean), items: items)
    }
}
