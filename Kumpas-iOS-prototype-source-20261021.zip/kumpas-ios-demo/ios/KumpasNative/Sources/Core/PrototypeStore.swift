import Foundation

/// Isolated JSON persistence for personal prototype use, not a research database.
/// The bridge must serialize access; concurrent instances/processes are unsupported.
public final class PrototypeStore {
    private enum StoreError: Error { case invalidPayload, unsupportedVersion }
    private struct Session: Codable {
        let id: String
        let participant_id: String
        let started_at: Int64
        var ended_at: Int64?
    }
    private struct Item: Codable, Equatable {
        let dimension: String
        let severity: Double
        let hand: String
        let prompt: String
    }
    private struct Attempt: Codable, Equatable {
        let attemptId: String?
        let targetClass: Int
        let targetLabel: String
        let predictedLabel: String
        let predictedConfidence: Double
        let recognizedAsTarget: Bool
        let overallMatch: Double
        let items: [Item]
    }
    private struct AttemptRecord: Codable {
        let sessionID: String
        let timestamp: Int64
        let payload: Attempt
    }
    private struct Assessment: Codable {
        let id: Int
        let participant_id: String
        let type: String
        let timestamp: Int64
        let responses: String
    }
    private struct Snapshot: Codable {
        var version = 1
        var participantID = UUID().uuidString
        var sessions: [Session] = []
        var attempts: [AttemptRecord] = []
        var assessments: [Assessment] = []
        var exports: [String] = []
    }
    private let directory: URL
    private let snapshotURL: URL
    private var state: Snapshot

    public init(directory: URL) throws {
        guard directory.isFileURL else { throw StoreError.invalidPayload }
        self.directory = directory.standardizedFileURL
        snapshotURL = self.directory.appendingPathComponent("prototype-store.json")
        try FileManager.default.createDirectory(at: self.directory, withIntermediateDirectories: true)
        if FileManager.default.fileExists(atPath: snapshotURL.path) {
            state = try JSONDecoder().decode(Snapshot.self, from: Data(contentsOf: snapshotURL))
            guard state.version == 1 else { throw StoreError.unsupportedVersion }
        } else {
            state = Snapshot()
            try persist(state)
        }
        Self.excludeFromBackup(self.directory)
    }

    public func participantID() throws -> String { state.participantID }

    public func startSession() throws -> String {
        var next = state
        let timestamp = Self.now()
        if let index = next.sessions.lastIndex(where: { $0.ended_at == nil }) {
            next.sessions[index].ended_at = timestamp
        }
        let id = UUID().uuidString
        next.sessions.append(Session(id: id, participant_id: next.participantID, started_at: timestamp))
        try commit(next)
        return id
    }

    public func endSession() throws {
        guard let index = state.sessions.lastIndex(where: { $0.ended_at == nil }) else { return }
        var next = state
        next.sessions[index].ended_at = Self.now()
        try commit(next)
    }

    public func activeSession() throws -> String? {
        state.sessions.last(where: { $0.ended_at == nil })?.id
    }

    public func appendAttempt(_ payload: [String: Any]) throws {
        guard JSONSerialization.isValidJSONObject(payload) else { throw StoreError.invalidPayload }
        let bytes = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
        let attempt = try JSONDecoder().decode(Attempt.self, from: bytes)
        if let id = attempt.attemptId {
            guard !id.isEmpty else { throw StoreError.invalidPayload }
            if let existing = state.attempts.first(where: { $0.payload.attemptId == id }) {
                guard existing.payload == attempt else { throw StoreError.invalidPayload }
                return // Acknowledges the already durable identical attempt, never a new write.
            }
        }
        var next = state
        let timestamp = Self.now()
        let sessionID: String
        if let active = next.sessions.last(where: { $0.ended_at == nil }) {
            sessionID = active.id
        } else {
            sessionID = UUID().uuidString
            next.sessions.append(Session(id: sessionID, participant_id: next.participantID, started_at: timestamp))
        }
        next.attempts.append(AttemptRecord(sessionID: sessionID, timestamp: timestamp, payload: attempt))
        try commit(next)
    }

    public func history() throws -> [[String: Any]] {
        try state.attempts.enumerated().sorted {
            if $0.element.timestamp == $1.element.timestamp { return $0.offset > $1.offset }
            return $0.element.timestamp > $1.element.timestamp
        }.map { try historyRow($0.element) }
    }

    private func historyRow(_ record: AttemptRecord) throws -> [String: Any] {
        var row = try Self.object(record.payload)
        row["timestamp"] = record.timestamp
        return row
    }

    private static func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        let bytes = try JSONEncoder().encode(value)
        guard let result = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] else {
            throw StoreError.invalidPayload
        }
        return result
    }
    public func saveAssessment(type: String, responses: String) throws {
        guard type == "pre" || type == "post",
              let data = responses.data(using: .utf8),
              let object = try JSONSerialization.jsonObject(with: data) as? [String: Any],
              JSONSerialization.isValidJSONObject(object) else { throw StoreError.invalidPayload }
        var next = state
        next.assessments.append(Assessment(id: next.assessments.count + 1,
            participant_id: next.participantID, type: type, timestamp: Self.now(), responses: responses))
        try commit(next)
    }

    public func assessments() throws -> [[String: Any]] {
        try state.assessments.map { try Self.object($0) }
    }
    public func exportData() throws -> String {
        let sessions: [[String: Any]] = try state.sessions.reversed().map { session in
            var row = try Self.object(session)
            row["ended_at"] = session.ended_at.map { $0 as Any } ?? NSNull()
            row["attempts"] = try state.attempts.filter { $0.sessionID == session.id }.map { try historyRow($0) }
            return row
        }
        let root: [String: Any] = [
            "metadata": ["participant_id": state.participantID, "prototype": true,
                         "export_timestamp": ISO8601DateFormatter().string(from: Date()),
                         "storage_format": "kumpas-personal-prototype-json-v1"],
            "sessions": sessions,
            "assessments": try assessments(),
            "summary": ["total_sessions": state.sessions.count, "total_attempts": state.attempts.count,
                        "total_assessments": state.assessments.count]
        ]
        let bytes = try JSONSerialization.data(withJSONObject: root, options: [.sortedKeys, .prettyPrinted])
        let name = "kumpas-prototype-export-\(UUID().uuidString).json"
        let destination = directory.appendingPathComponent(name)
        // Persist ownership first so purge can recover an interrupted export.
        var next = state
        next.exports.append(name)
        try commit(next)
        // Foundation's exclusive write rejects an existing destination, even on collision.
        // Snapshots use .atomic; exports deliberately use .withoutOverwriting instead.
        try bytes.write(to: destination, options: .withoutOverwriting)
        Self.excludeFromBackup(destination)
        guard try Data(contentsOf: destination) == bytes else { throw StoreError.invalidPayload }
        return destination.path
    }
    public func clearAllData() throws {
        // Delete only manifest-owned, strictly scoped names. Never remove the directory.
        // Keep the old manifest until all export removal succeeds so failures are retryable.
        for name in state.exports {
            guard Self.isExportName(name) else { throw StoreError.invalidPayload }
            let url = directory.appendingPathComponent(name)
            let attributes: [FileAttributeKey: Any]
            do {
                // attributesOfItem uses the link entry, including a dangling link.
                attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            } catch let error as CocoaError where error.code == .fileReadNoSuchFile {
                continue
            }
            let type = attributes[.type] as? FileAttributeType
            guard type == .typeRegular || type == .typeSymbolicLink else {
                throw StoreError.invalidPayload // Never recurse into an unexpected directory.
            }
            try FileManager.default.removeItem(at: url)
        }
        try commit(Snapshot())
    }

    private static func isExportName(_ name: String) -> Bool {
        let prefix = "kumpas-prototype-export-"
        guard name.hasPrefix(prefix), name.hasSuffix(".json") else { return false }
        let uuid = String(name.dropFirst(prefix.count).dropLast(5))
        return UUID(uuidString: uuid)?.uuidString == uuid
    }

    private static func now() -> Int64 { Int64(Date().timeIntervalSince1970 * 1000) }
    private func persist(_ snapshot: Snapshot) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        try encoder.encode(snapshot).write(to: snapshotURL, options: .atomic)
        Self.excludeFromBackup(snapshotURL)
    }
    private func commit(_ snapshot: Snapshot) throws {
        try persist(snapshot)
        state = snapshot // Never acknowledge or change memory before the durable write.
    }
    private static func excludeFromBackup(_ url: URL) {
        #if os(iOS) || os(macOS) || os(tvOS) || os(watchOS) || os(visionOS)
        var mutable = url
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try? mutable.setResourceValues(values)
        #endif
    }
}
