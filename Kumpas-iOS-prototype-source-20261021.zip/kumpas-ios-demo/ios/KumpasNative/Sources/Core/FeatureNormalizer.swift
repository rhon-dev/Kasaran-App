import Foundation

public enum FeatureNormalizer {
    public static func normalize(_ features: [Float], poseSeen: Bool) throws -> [Float] {
        guard features.count == 258, features.allSatisfy({ $0.isFinite }) else {
            throw NSError(domain: "KumpasMath", code: 1, userInfo: [NSLocalizedDescriptionKey: "Expected 258 finite pose/hand features"])
        }
        guard poseSeen else { return features }
        var f = features
        var root = [Float](repeating: 0, count: 3)
        var neck = root
        for k in 0..<3 {
            root[k] = (f[92 + k] + f[96 + k]) / Float(2)
            neck[k] = (f[44 + k] + f[48 + k]) / Float(2)
        }
        let d = (0..<3).map { neck[$0] - root[$0] }
        var scale = (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).squareRoot()
        guard root.allSatisfy({ $0.isFinite }), neck.allSatisfy({ $0.isFinite }), scale.isFinite else {
            throw NSError(domain: "KumpasMath", code: 2, userInfo: [NSLocalizedDescriptionKey: "Normalization geometry overflow"])
        }
        if scale < 1e-4 { scale = 1 }
        for i in 0..<33 { for k in 0..<3 { f[i * 4 + k] = (f[i * 4 + k] - root[k]) / scale } }
        for base in [132, 195] where f[base..<(base + 63)].contains(where: { $0 != 0 }) {
            for i in 0..<21 { for k in 0..<3 { f[base + i * 3 + k] = (f[base + i * 3 + k] - root[k]) / scale } }
        }
        guard f.allSatisfy({ $0.isFinite }) else {
            throw NSError(domain: "KumpasMath", code: 2, userInfo: [NSLocalizedDescriptionKey: "Normalization overflow"])
        }
        return f
    }
}
