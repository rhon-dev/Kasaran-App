import Foundation

/// Cross-queue revocation fence. Camera callbacks and posted main-queue events
/// must pass this gate; revocation never waits behind a slow inference.
final class NativeLifecycleGate {
    struct Attempt { let id: String; let revision: UInt64 }
    private let lock = NSRecursiveLock()
    private var camera: UUID?
    private var revision: UInt64 = 0
    private var attemptID: String?
    private var closed = false
    private var listener: UInt64 = 0
    func listenerRevision() -> UInt64 { locked { listener } }
    func changeListener() { locked { listener &+= 1 } }
    func shutdown() { locked { closed = true; camera = nil; attemptID = nil; revision &+= 1; listener &+= 1 } }

    private func locked<T>(_ work: () throws -> T) rethrows -> T {
        lock.lock(); defer { lock.unlock() }; return try work()
    }
    func claimCamera() -> UUID { locked {
        guard !closed else { return UUID() }
        revision &+= 1; attemptID = nil
        let token = UUID(); camera = token; return token
    } }
    @discardableResult func releaseCamera(_ token: UUID) -> Bool { locked {
        guard camera == token else { return false }
        revision &+= 1; camera = nil; attemptID = nil; return true
    } }
    func isCurrent(_ token: UUID) -> Bool { locked { camera == token } }
    func currentCamera() -> UUID? { locked { camera } }
    func currentRevision() -> UInt64 { locked { revision } }
    func beginAttempt(camera token: UUID) -> Attempt? { locked {
        guard camera == token else { return nil }
        revision &+= 1
        let id = UUID().uuidString.lowercased(); attemptID = id
        return Attempt(id: id, revision: revision)
    } }
    @discardableResult func cancelAttempt(id: String?) -> Bool { locked {
        guard id == nil || id == attemptID else { return false }
        revision &+= 1; attemptID = nil; return true
    } }
    func canDeliver(camera token: UUID, revision expected: UInt64) -> Bool {
        locked { camera == token && revision == expected }
    }
    /// Linearizes terminal persistence with camera/cancellation revocation.
    /// This lock is never held for inference, only the small local store write.
    func ifCurrent<T>(camera token: UUID, revision expected: UInt64,
                      _ work: () throws -> T) rethrows -> T? {
        try locked {
            guard camera == token && revision == expected else { return nil }
            return try work()
        }
    }
}
