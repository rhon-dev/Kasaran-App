import Foundation

struct NativeFailure: LocalizedError {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

final class NativeAssets: NSObject {
    let labelsJSON: String
    let labels: [String]
    let gold: [[[Float]]]

    static func url(_ filename: String) throws -> URL {
        // Pods resource bundles can be adjacent to the framework or in main.
        let roots = [Bundle(for: NativeAssets.self), Bundle.main] + Bundle.allFrameworks + Bundle.allBundles
        var candidates = [Bundle]()
        var paths = Set<String>()
        for root in roots {
            if let url = root.url(forResource: "KumpasModels", withExtension: "bundle"),
               let bundle = Bundle(url: url), paths.insert(bundle.bundlePath).inserted {
                candidates.append(bundle)
            }
            if root.bundleURL.lastPathComponent == "KumpasModels.bundle",
               paths.insert(root.bundlePath).inserted { candidates.append(root) }
        }
        for bundle in candidates {
            if let url = bundle.url(forResource: filename, withExtension: nil) { return url }
        }
        throw NativeFailure("Missing \(filename) in KumpasModels.bundle (main or KumpasNative resources).")
    }

    private init(labelsJSON: String, labels: [String], gold: [[[Float]]]) {
        self.labelsJSON = labelsJSON; self.labels = labels; self.gold = gold
        super.init()
    }
    static func loadAssets() throws -> NativeAssets {
        let bytes = try Data(contentsOf: url("label_map.json"))
        guard let text = String(data: bytes, encoding: .utf8),
              let map = try JSONSerialization.jsonObject(with: bytes) as? [String: [String: Any]],
              map.count == 50 else { throw NativeFailure("Expected 50 label-map entries.") }
        let labels = try (0..<50).map { index -> String in
            guard let entry = map[String(index)], let label = entry["label"] as? String,
                  !label.isEmpty, entry["category"] is String else {
                throw NativeFailure("Invalid label-map entry \(index).")
            }
            return label
        }
        let goldBytes = try Data(contentsOf: url("gold_standards.bin"))
        let values = try floats(goldBytes, count: 50 * 30 * 258)
        let gold = (0..<50).map { sign in
            (0..<30).map { frame in
                Array(values[((sign * 30 + frame) * 258)..<((sign * 30 + frame + 1) * 258)])
            }
        }
        return NativeAssets(labelsJSON: text, labels: labels, gold: gold)
    }
    static func floats(_ data: Data, count: Int) throws -> [Float] {
        guard data.count == count * 4 else { throw NativeFailure("Float32 data size mismatch: \(data.count), expected \(count * 4).") }
        let bytes = [UInt8](data)
        let values = (0..<count).map { i -> Float in
            let p = i * 4
            let bits = UInt32(bytes[p]) | UInt32(bytes[p+1]) << 8 | UInt32(bytes[p+2]) << 16 | UInt32(bytes[p+3]) << 24
            return Float(bitPattern: bits)
        }
        guard values.allSatisfy({ $0.isFinite }) else { throw NativeFailure("Non-finite Float32 data.") }
        return values
    }
}

