import Foundation
import UIKit
import AVFoundation

/// All mutable capture/model/store state below is confined to `queue`.
final class NativeCoordinator: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let queue = DispatchQueue(label: "org.kumpas.ios.capture-inference", qos: .userInitiated)
    let gate = NativeLifecycleGate()
    var event: (([String: Any], UUID?, UInt64) -> Void)?
    private var session: AVCaptureSession?
    private var output: AVCaptureVideoDataOutput?
    private var sessionOwner: UUID?
    private var model: NativeModel?
    private var store: PrototypeStore?
    private var observers = [NSObjectProtocol]()
    private var lastError: String?
    private var window = [[Float]]()
    private var poses = [Bool]()
    private var sinceInference = 0
    private var lastSample = -Double.infinity
    private var fpsStart = 0.0
    private var fpsCount = 0
    private var cameraFPS = 0.0
    private struct CaptureAttempt {
        let id: String
        let revision: UInt64
        let target: Int
        var frames = [[Float]]()
        var poses = 0
    }
    private var attempt: CaptureAttempt?

    private func emit(_ payload: [String: Any], owner: UUID? = nil, revision: UInt64? = nil) {
        event?(payload, owner, revision ?? gate.currentRevision())
    }
    func shutdown() {
        gate.shutdown()
        queue.async { self.stopSession(); self.store = nil; self.lastError = nil }
    }
    func listenerReady() {
        queue.async {
            if let error = self.lastError { self.emit(["state": "camera_error", "reason": error]) }
        }
    }
    private func localStore() throws -> PrototypeStore {
        if let store = store { return store }
        let base = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask,
                                               appropriateFor: nil, create: true)
        let directory = base.appendingPathComponent("KumpasIOSPrototype", isDirectory: true)
        let created = try PrototypeStore(directory: directory)
        store = created
        return created
    }
    // Main-thread callers revoke immediately; stopping never blocks the UI.
    func attach(layer: AVCaptureVideoPreviewLayer) -> UUID {
        let token = gate.claimCamera()
        queue.async {
            self.stopSession()
            guard self.gate.isCurrent(token) else { return }
            self.requestPermission(token: token, layer: layer)
        }
        return token
    }
    func detach(_ token: UUID) {
        guard gate.releaseCamera(token) else { return }
        queue.async {
            // A disposed old view cannot stop a replacement session.
            if self.sessionOwner == token { self.stopSession() }
        }
    }
    private func requestPermission(token: UUID, layer: AVCaptureVideoPreviewLayer) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: configure(token: token, layer: layer)
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                self.queue.async {
                    guard self.gate.isCurrent(token) else { return }
                    if granted { self.configure(token: token, layer: layer) }
                    else { self.failCamera("Camera permission denied. Enable Camera in Settings.", token: token) }
                }
            }
        default: failCamera("Camera permission denied or restricted. Enable Camera in Settings.", token: token)
        }
    }
    private func configure(token: UUID, layer: AVCaptureVideoPreviewLayer) {
        guard gate.isCurrent(token) else { return }
        do {
            let loaded = try NativeModel()
            guard gate.isCurrent(token) else { return }
            guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
                throw NativeFailure("Front camera unavailable.")
            }
            let capture = AVCaptureSession()
            capture.beginConfiguration()
            capture.sessionPreset = .vga640x480
            let input = try AVCaptureDeviceInput(device: device)
            let frames = AVCaptureVideoDataOutput()
            frames.alwaysDiscardsLateVideoFrames = true
            frames.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
            guard capture.canAddInput(input) else { throw NativeFailure("Cannot attach front camera input.") }
            capture.addInput(input)
            guard capture.canAddOutput(frames) else { throw NativeFailure("Cannot attach video output.") }
            capture.addOutput(frames)
            guard let connection = frames.connection(with: .video), connection.isVideoOrientationSupported,
                  connection.isVideoMirroringSupported else {
                throw NativeFailure("Camera cannot provide portrait, unmirrored model frames.")
            }
            connection.videoOrientation = .portrait
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = false
            frames.setSampleBufferDelegate(self, queue: queue)
            capture.commitConfiguration()
            session = capture; output = frames; model = loaded; sessionOwner = token
            lastError = nil
            window.removeAll(); poses.removeAll(); attempt = nil; sinceInference = 0
            lastSample = -.infinity; fpsStart = ProcessInfo.processInfo.systemUptime; fpsCount = 0
            observe(capture, token: token)
            DispatchQueue.main.async { [weak self, weak layer, weak capture] in
                guard let self = self, self.gate.isCurrent(token), let layer = layer else { return }
                layer.session = capture
                layer.videoGravity = .resizeAspectFill
                if let preview = layer.connection {
                    if preview.isVideoOrientationSupported { preview.videoOrientation = .portrait }
                    if preview.isVideoMirroringSupported {
                        preview.automaticallyAdjustsVideoMirroring = false; preview.isVideoMirrored = true
                    }
                }
            }
            guard gate.isCurrent(token) else { stopSession(); return }
            capture.startRunning()
            guard capture.isRunning else { throw NativeFailure("Camera session did not start.") }
            emit(["state": "warmup", "bufferFill": 0, "cameraFps": 0, "landmarkMs": 0, "handsVisible": 0], owner: token)
        } catch { failCamera("Camera/model initialization failed: \(error.localizedDescription)", token: token) }
    }
    private func observe(_ capture: AVCaptureSession, token: UUID) {
        for name in [AVCaptureSession.wasInterruptedNotification, AVCaptureSession.runtimeErrorNotification] {
            let observer = NotificationCenter.default.addObserver(forName: name, object: capture, queue: nil) { [weak self] note in
                guard let self = self, self.gate.releaseCamera(token) else { return }
                let reason = note.name == AVCaptureSession.wasInterruptedNotification
                    ? "Camera interrupted. Return to this screen to restart capture."
                    : "Camera runtime failure: \((note.userInfo?[AVCaptureSessionErrorKey] as? Error)?.localizedDescription ?? "unknown error")"
                let revision = self.gate.currentRevision()
                self.queue.async {
                    if self.sessionOwner == token { self.stopSession() }
                    guard self.gate.currentRevision() == revision else { return }
                    self.lastError = reason
                    self.emit(["state": "camera_error", "reason": reason], revision: revision)
                }
            }
            observers.append(observer)
        }
    }
    private func failCamera(_ reason: String, token: UUID) {
        guard gate.isCurrent(token) else { return }
        gate.cancelAttempt(id: nil)
        stopSession()
        lastError = reason
        emit(["state": "camera_error", "reason": reason], owner: token)
    }
    private func stopSession() {
        observers.forEach { NotificationCenter.default.removeObserver($0) }; observers.removeAll()
        output?.setSampleBufferDelegate(nil, queue: nil)
        session?.stopRunning()
        if let session = session {
            session.beginConfiguration()
            session.inputs.forEach { session.removeInput($0) }
            session.outputs.forEach { session.removeOutput($0) }
            session.commitConfiguration()
        }
        output = nil; session = nil; sessionOwner = nil; model = nil; attempt = nil
        window.removeAll(); poses.removeAll()
    }

    func control(_ method: String, arguments: [String: Any], completion: @escaping (Any?, Error?) -> Void) {
        // Revoke queued terminal events synchronously on cancellation/purge.
        if method == "cancelAttempt" {
            if let outcome = arguments["outcome"] as? String, !["cancelled", "timeout"].contains(outcome) {
                completion(nil, NativeFailure("Invalid cancellation outcome.")); return
            }
            gate.cancelAttempt(id: arguments["attemptId"] as? String)
        } else if method == "clearAllData" || method == "endSession" {
            gate.cancelAttempt(id: nil)
        }
        queue.async {
            do { completion(try self.perform(method, arguments: arguments), nil) }
            catch { completion(nil, error) }
        }
    }
    private func json(_ object: Any) throws -> String {
        String(decoding: try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys]), as: UTF8.self)
    }
    private func perform(_ method: String, arguments: [String: Any]) throws -> Any? {
        switch method {
        case "getLabels": return try (model?.assets ?? NativeAssets.loadAssets()).labelsJSON
        case "startAttempt":
            guard let target = arguments["classId"] as? Int, (0..<50).contains(target) else {
                throw NativeFailure("classId must be an integer in 0...49.")
            }
            guard let token = sessionOwner, gate.isCurrent(token), session?.isRunning == true, model != nil,
                  AVCaptureDevice.authorizationStatus(for: .video) == .authorized else {
                throw NativeFailure(lastError ?? "Camera is not ready.")
            }
            _ = try localStore() // Surface unavailable persistence before collecting.
            guard let identity = gate.beginAttempt(camera: token) else { throw NativeFailure("Camera owner changed.") }
            attempt = CaptureAttempt(id: identity.id, revision: identity.revision, target: target)
            return identity.id
        case "cancelAttempt":
            if arguments["attemptId"] == nil || arguments["attemptId"] is NSNull ||
                arguments["attemptId"] as? String == attempt?.id { attempt = nil }
            return nil
        case "feedbackPresented":
            guard let id = arguments["attemptId"] as? String, !id.isEmpty else { throw NativeFailure("Missing attempt identity.") }
            // No research/display-latency claim is produced by this prototype.
            return nil
        case "getHistory": return try json(localStore().history())
        case "startSession":
            gate.cancelAttempt(id: nil); attempt = nil
            return try localStore().startSession()
        case "endSession": attempt = nil; try localStore().endSession(); return nil
        case "getActiveSession": return try localStore().activeSession()
        case "getParticipantId": return try localStore().participantID()
        case "saveAssessment":
            guard let type = arguments["type"] as? String, let responses = arguments["responses"] as? String else {
                throw NativeFailure("Missing assessment type or encoded responses.")
            }
            try localStore().saveAssessment(type: type, responses: responses); return nil
        case "getAssessments": return try json(localStore().assessments())
        case "exportData": return try localStore().exportData()
        case "clearAllData": attempt = nil; window.removeAll(); poses.removeAll(); try localStore().clearAllData(); return nil
        default: throw NativeFailure("Unsupported control method: \(method).")
        }
    }

    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard output === self.output, let token = sessionOwner, gate.isCurrent(token), let model = model else { return }
        let now = ProcessInfo.processInfo.systemUptime
        fpsCount += 1
        if now - fpsStart >= 1 { cameraFPS = Double(fpsCount) / (now - fpsStart); fpsCount = 0; fpsStart = now }
        guard now - lastSample >= 0.133 else { return }
        lastSample = now
        let revision = gate.currentRevision()
        do {
            let frame = try model.extract(sampleBuffer)
            guard gate.canDeliver(camera: token, revision: revision) else { return }
            let stats: [String: Any] = ["cameraFps": cameraFPS, "landmarkMs": frame.landmarkMS, "handsVisible": frame.handsSeen]
            window.append(frame.features); poses.append(frame.poseSeen)
            if window.count > 30 { window.removeFirst(); poses.removeFirst() }
            sinceInference += 1
            if var active = attempt, active.revision == revision {
                active.frames.append(frame.features)
                if frame.poseSeen { active.poses += 1 }
                attempt = active
                if active.frames.count < 30 {
                    var payload = stats
                    payload["state"] = "attempt_progress"; payload["attemptId"] = active.id
                    payload["collected"] = active.frames.count; payload["needed"] = 30
                    emit(payload, owner: token, revision: revision)
                } else {
                    attempt = nil
                    try complete(active, model: model, token: token)
                }
                return
            }
            if window.count == 30 && sinceInference >= 4 {
                sinceInference = 0
                guard poses.filter({ $0 }).count >= 15 else {
                    var payload = stats; payload["state"] = "no_signer"; emit(payload, owner: token, revision: revision); return
                }
                let inference = try model.classify(window)
                let top = inference.scores.indices.sorted { inference.scores[$0] > inference.scores[$1] }.prefix(3)
                guard let best = top.first else { throw NativeFailure("Empty classifier output.") }
                var payload = stats
                payload["state"] = "prediction"; payload["label"] = model.assets.labels[best]
                payload["confidence"] = Double(inference.scores[best]); payload["inferMs"] = inference.milliseconds
                payload["top3"] = top.map { ["label": model.assets.labels[$0], "p": Double(inference.scores[$0])] as [String: Any] }
                emit(payload, owner: token, revision: revision)
            } else {
                var payload = stats; payload["state"] = "warmup"; payload["bufferFill"] = window.count
                emit(payload, owner: token, revision: revision)
            }
        } catch { failCamera("Landmark/inference failure: \(error.localizedDescription)", token: token) }
    }
    private func complete(_ active: CaptureAttempt, model: NativeModel, token: UUID) throws {
        guard active.poses >= 15 else {
            emit(["state": "attempt_failed", "attemptId": active.id, "outcome": "no_signer",
                  "reason": "No signer detected — stand in front of the camera and try again."],
                 owner: token, revision: active.revision)
            return
        }
        let prediction = try model.classify(active.frames)
        guard let best = prediction.scores.indices.max(by: { prediction.scores[$0] < prediction.scores[$1] }) else {
            throw NativeFailure("Empty classifier output.")
        }
        let report = try FeedbackEngine.compare(learner: active.frames, gold: model.assets.gold[active.target],
                                                targetLabel: model.assets.labels[active.target])
        let payload: [String: Any] = [
            "state": "attempt_result", "attemptId": active.id, "targetClass": active.target,
            "targetLabel": model.assets.labels[active.target], "predictedLabel": model.assets.labels[best],
            "predictedConfidence": Double(prediction.scores[best]), "recognizedAsTarget": best == active.target,
            "overallMatch": report.overallMatch,
            "items": report.items.map { ["dimension": $0.dimension, "severity": $0.severity, "hand": $0.hand, "prompt": $0.prompt] as [String: Any] },
            "timestamp": Int64(Date().timeIntervalSince1970 * 1000)
        ]
        do {
            let saved: Bool? = try gate.ifCurrent(camera: token, revision: active.revision) {
                try localStore().appendAttempt(payload); return true
            }
            guard saved == true else { return }
            emit(payload, owner: token, revision: active.revision)
        } catch {
            emit(["state": "attempt_failed", "attemptId": active.id, "outcome": "persistence_failed",
                  "reason": "Attempt could not be saved: \(error.localizedDescription)"], owner: token, revision: active.revision)
        }
    }
    deinit {
        observers.forEach { NotificationCenter.default.removeObserver($0) }
        output?.setSampleBufferDelegate(nil, queue: nil)
        session?.stopRunning()
    }
}
