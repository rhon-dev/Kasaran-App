import Foundation
import Flutter

/// The only public native registration entry point; core types are in this same pod.
public final class KumpasPlugin: NSObject, FlutterPlugin, FlutterStreamHandler {
    private let coordinator = NativeCoordinator()
    private var sink: FlutterEventSink?
    private var detached = false
    private var methodChannel: FlutterMethodChannel?
    private var eventChannel: FlutterEventChannel?
    private static let supported: Set<String> = [
        "getLabels", "startAttempt", "cancelAttempt", "feedbackPresented", "getHistory", "startSession",
        "endSession", "getActiveSession", "saveAssessment", "getAssessments", "exportData", "clearAllData", "getParticipantId"
    ]
    private static let benchmarks: Set<String> = [
        "startBenchmark", "confirmBenchmarkStart", "stopBenchmark", "getBenchmarkReport", "isBenchmarkActive"
    ]

    public static func register(with registrar: FlutterPluginRegistrar) {
        let plugin = KumpasPlugin()
        let methods = FlutterMethodChannel(name: "kumpas/control", binaryMessenger: registrar.messenger())
        let events = FlutterEventChannel(name: "kumpas/predictions", binaryMessenger: registrar.messenger())
        plugin.methodChannel = methods; plugin.eventChannel = events
        registrar.addMethodCallDelegate(plugin, channel: methods)
        registrar.publish(plugin) // Required for Flutter engine-detachment cleanup callbacks.
        events.setStreamHandler(plugin)
        registrar.register(KumpasCameraFactory(coordinator: plugin.coordinator), withId: "kumpas/camera_preview")
        plugin.coordinator.event = { [weak plugin] payload, owner, revision in
            guard let coordinator = plugin?.coordinator else { return }
            let subscription = coordinator.gate.listenerRevision()
            DispatchQueue.main.async { [weak plugin] in
                guard let plugin = plugin, !plugin.detached,
                      plugin.coordinator.gate.listenerRevision() == subscription,
                      plugin.coordinator.gate.currentRevision() == revision,
                      owner.map({ plugin.coordinator.gate.isCurrent($0) }) ?? true else { return }
                guard let sink = plugin.sink else { return }
                do {
                    let bytes = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
                    sink(String(decoding: bytes, as: UTF8.self))
                } catch {
                    // Even malformed/non-finite data is explicit; no substitute scores.
                    sink("{\"state\":\"camera_error\",\"reason\":\"Native event encoding failed.\"}")
                }
            }
        }
    }

    public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
        guard !detached else { result(FlutterError(code: "CONTROL_FAILED", message: "Native engine detached.", details: nil)); return }
        if Self.benchmarks.contains(call.method) {
            result(FlutterError(code: "UNSUPPORTED_BENCHMARK", message: "Research benchmarks are not implemented or qualified by the iOS personal-test prototype.", details: nil)); return
        }
        guard Self.supported.contains(call.method) else { result(FlutterMethodNotImplemented); return }
        let args = call.arguments as? [String: Any] ?? [:]
        coordinator.control(call.method, arguments: args) { value, error in
            DispatchQueue.main.async {
                if let error = error {
                    let code: String
                    switch call.method {
                    case "startAttempt": code = "CAMERA_ERROR"
                    case "clearAllData": code = "CLEAR_FAILED"
                    case "exportData": code = "EXPORT_FAILED"
                    default: code = "CONTROL_FAILED"
                    }
                    result(FlutterError(code: code, message: error.localizedDescription, details: nil))
                } else { result(value) }
            }
        }
    }
    public func onListen(withArguments arguments: Any?, eventSink events: @escaping FlutterEventSink) -> FlutterError? {
        coordinator.gate.changeListener(); sink = events
        coordinator.listenerReady()
        return nil
    }
    public func onCancel(withArguments arguments: Any?) -> FlutterError? {
        coordinator.gate.changeListener(); sink = nil
        return nil
    }
    public func detachFromEngine(for registrar: FlutterPluginRegistrar) {
        detached = true; coordinator.gate.changeListener(); sink = nil
        methodChannel?.setMethodCallHandler(nil); eventChannel?.setStreamHandler(nil)
        coordinator.shutdown()
    }
}
