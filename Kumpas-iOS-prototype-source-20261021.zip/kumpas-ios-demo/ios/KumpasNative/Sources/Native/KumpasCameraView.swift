import UIKit
import AVFoundation
import Flutter

final class KumpasCameraSurface: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    private let coordinator: NativeCoordinator
    private var token: UUID?
    private var canResumeAfterForeground = true
    private var observers = [NSObjectProtocol]()

    init(frame: CGRect, coordinator: NativeCoordinator) {
        self.coordinator = coordinator
        super.init(frame: frame)
        backgroundColor = .black
        // Privacy: loss of foreground immediately invalidates attempts/events;
        // the serial capture queue then releases hardware and landmark tasks.
        for name in [UIApplication.willResignActiveNotification, UIApplication.didEnterBackgroundNotification] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] _ in
                guard let self = self else { return }
                if let token = self.token { self.canResumeAfterForeground = self.coordinator.gate.isCurrent(token) }
                self.deactivate()
            })
        }
        observers.append(NotificationCenter.default.addObserver(forName: UIApplication.didBecomeActiveNotification,
                                                               object: nil, queue: .main) { [weak self] _ in self?.activateIfVisible() })
    }
    required init?(coder: NSCoder) { return nil }
    override func didMoveToWindow() {
        super.didMoveToWindow()
        if window == nil { deactivate() } else { canResumeAfterForeground = true; activateIfVisible() }
    }
    private func activateIfVisible() {
        guard canResumeAfterForeground, window != nil, UIApplication.shared.applicationState == .active else { return }
        if let token = token, coordinator.gate.isCurrent(token) { return }
        token = coordinator.attach(layer: layer as! AVCaptureVideoPreviewLayer)
    }
    func deactivate() {
        if let token = token { coordinator.detach(token) }
        token = nil
        (layer as? AVCaptureVideoPreviewLayer)?.session = nil
    }
    deinit {
        observers.forEach { NotificationCenter.default.removeObserver($0) }
        if let token = token { coordinator.detach(token) }
    }
}

final class KumpasCameraView: NSObject, FlutterPlatformView {
    private let surface: KumpasCameraSurface
    init(frame: CGRect, coordinator: NativeCoordinator) {
        surface = KumpasCameraSurface(frame: frame, coordinator: coordinator)
        super.init()
    }
    func view() -> UIView { surface }
    deinit { surface.deactivate() }
}

final class KumpasCameraFactory: NSObject, FlutterPlatformViewFactory {
    private let coordinator: NativeCoordinator
    init(coordinator: NativeCoordinator) { self.coordinator = coordinator; super.init() }
    func createArgsCodec() -> FlutterMessageCodec & NSObjectProtocol { FlutterStandardMessageCodec.sharedInstance() }
    func create(withFrame frame: CGRect, viewIdentifier viewId: Int64, arguments args: Any?) -> FlutterPlatformView {
        KumpasCameraView(frame: frame, coordinator: coordinator)
    }
}
