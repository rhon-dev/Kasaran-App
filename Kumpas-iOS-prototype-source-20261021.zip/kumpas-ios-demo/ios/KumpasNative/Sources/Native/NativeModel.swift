import Foundation
import UIKit
import AVFoundation
import MediaPipeTasksVision
import TensorFlowLite

/// Confined to the single capture/inference queue. No mock fallback.
final class NativeModel {
    struct Frame {
        let features: [Float]
        let poseSeen: Bool
        let handsSeen: Int
        let landmarkMS: Double
    }
    let assets: NativeAssets
    private let pose: PoseLandmarker
    private let hands: HandLandmarker
    private let interpreter: Interpreter
    private var lastTimestamp = -1

    init() throws {
        assets = try NativeAssets.loadAssets()
        let poseOptions = PoseLandmarkerOptions()
        poseOptions.baseOptions.modelAssetPath = try NativeAssets.url("pose_landmarker_lite.task").path
        poseOptions.runningMode = .video
        poseOptions.numPoses = 1
        poseOptions.minPoseDetectionConfidence = 0.5
        poseOptions.minPosePresenceConfidence = 0.5
        poseOptions.minTrackingConfidence = 0.5
        pose = try PoseLandmarker(options: poseOptions)
        let handOptions = HandLandmarkerOptions()
        handOptions.baseOptions.modelAssetPath = try NativeAssets.url("hand_landmarker.task").path
        handOptions.runningMode = .video
        handOptions.numHands = 2
        handOptions.minHandDetectionConfidence = 0.5
        handOptions.minHandPresenceConfidence = 0.5
        handOptions.minTrackingConfidence = 0.5
        hands = try HandLandmarker(options: handOptions)
        var options = Interpreter.Options(); options.threadCount = 2
        interpreter = try Interpreter(modelPath: NativeAssets.url("kumpas_50sign.tflite").path, options: options)
        try interpreter.allocateTensors()
        guard interpreter.inputTensorCount == 1, interpreter.outputTensorCount == 1 else {
            throw NativeFailure("Classifier must have exactly one input and output.")
        }
        let input = try interpreter.input(at: 0), output = try interpreter.output(at: 0)
        guard input.dataType == .float32, input.shape.dimensions == [1, 30, 258],
              output.dataType == .float32, output.shape.dimensions == [1, 50] else {
            throw NativeFailure("Classifier expected float32 [1,30,258] -> [1,50]; got \(input.shape.dimensions) -> \(output.shape.dimensions).")
        }
    }

    func extract(_ sample: CMSampleBuffer) throws -> Frame {
        let start = ProcessInfo.processInfo.systemUptime
        // The capture connection physically rotates pixels to portrait and explicitly
        // disables mirroring. Do not apply a second orientation rotation here.
        let image = try MPImage(sampleBuffer: sample, orientation: .up)
        let pts = CMTimeGetSeconds(CMSampleBufferGetPresentationTimeStamp(sample))
        guard pts.isFinite, pts >= 0 else { throw NativeFailure("Invalid camera timestamp.") }
        let timestamp = max(lastTimestamp + 1, Int(pts * 1000))
        lastTimestamp = timestamp
        let p = try pose.detect(videoFrame: image, timestampInMilliseconds: timestamp)
        let h = try hands.detect(videoFrame: image, timestampInMilliseconds: timestamp)
        var features = [Float](repeating: 0, count: 258)
        let poseSeen = p.landmarks.first?.count == 33
        if let landmarks = p.landmarks.first {
            guard landmarks.count == 33 else { throw NativeFailure("Pose landmark count is not 33.") }
            for (i, point) in landmarks.enumerated() {
                features[i * 4] = point.x; features[i * 4 + 1] = point.y
                features[i * 4 + 2] = point.z
                features[i * 4 + 3] = point.visibility?.floatValue ?? 0
            }
        }
        var occupied = Set<Int>()
        for (i, landmarks) in h.landmarks.enumerated() {
            guard landmarks.count == 21, i < h.handedness.count,
                  let category = h.handedness[i].first?.categoryName,
                  category == "Left" || category == "Right" else {
                throw NativeFailure("Invalid hand landmarks or handedness.")
            }
            // Preserve the Android pipeline's literal MediaPipe handedness mapping.
            // Actual anatomical agreement on the front camera is a device acceptance check.
            let base = category == "Left" ? 132 : 195
            guard occupied.insert(base).inserted else { throw NativeFailure("Duplicate hand-side detection.") }
            for (j, point) in landmarks.enumerated() {
                features[base + j * 3] = point.x; features[base + j * 3 + 1] = point.y
                features[base + j * 3 + 2] = point.z
            }
        }
        guard features.allSatisfy({ $0.isFinite }) else { throw NativeFailure("Non-finite landmarks.") }
        return Frame(features: try FeatureNormalizer.normalize(features, poseSeen: poseSeen),
                     poseSeen: poseSeen, handsSeen: h.landmarks.count,
                     landmarkMS: (ProcessInfo.processInfo.systemUptime - start) * 1000)
    }
    func classify(_ window: [[Float]]) throws -> (scores: [Float], milliseconds: Double) {
        guard window.count == 30, window.allSatisfy({ $0.count == 258 && $0.allSatisfy({ $0.isFinite }) }) else {
            throw NativeFailure("Classifier requires 30 finite 258-feature frames.")
        }
        var bytes = Data(capacity: 30 * 258 * 4)
        for value in window.joined() {
            var little = value.bitPattern.littleEndian
            withUnsafeBytes(of: &little) { bytes.append(contentsOf: $0) }
        }
        let start = ProcessInfo.processInfo.systemUptime
        try interpreter.copy(bytes, toInputAt: 0)
        try interpreter.invoke()
        let scores = try NativeAssets.floats(interpreter.output(at: 0).data, count: 50)
        return (scores, (ProcessInfo.processInfo.systemUptime - start) * 1000)
    }
}
