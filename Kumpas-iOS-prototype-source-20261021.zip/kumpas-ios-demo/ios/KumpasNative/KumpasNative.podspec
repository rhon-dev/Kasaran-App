Pod::Spec.new do |s|
  s.name = 'KumpasNative'
  s.version = '0.1.0'
  s.summary = 'Separate Kumpas iOS personal-test prototype.'
  s.description = 'Real camera, landmark extraction, existing model inference and feedback. Not an approved thesis platform or study instrument.'
  s.homepage = 'https://github.com/rhon-dev/Kumpas'
  s.license = { :type => 'Private', :text => 'Local development prototype; not published as a pod.' }
  s.author = 'Kumpas project'
  s.source = { :path => '.' }
  s.source_files = 'Sources/**/*.swift'
  s.resource_bundles = { 'KumpasModels' => ['Assets/*'] }
  s.ios.deployment_target = '15.0'
  s.swift_version = '5.0'
  s.static_framework = true
  s.dependency 'Flutter'
  s.dependency 'MediaPipeTasksVision', '= 0.10.21'
  s.dependency 'TensorFlowLiteSwift', '= 2.14.0'
  s.frameworks = 'AVFoundation', 'UIKit', 'CoreMedia', 'CoreVideo'
  s.pod_target_xcconfig = {
    'DEFINES_MODULE' => 'YES',
    'CLANG_CXX_LANGUAGE_STANDARD' => 'c++17'
  }
end
