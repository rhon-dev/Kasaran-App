import Foundation
#if !HOST_CHECK
import XCTest
@testable import KumpasCore
#endif

enum MathChecks {
    static func require(_ condition: Bool, _ message: String) throws {
        if !condition { throw NSError(domain: "MathChecks", code: 1, userInfo: [NSLocalizedDescriptionKey: message]) }
    }
    static func normalization() throws {
        var f = [Float](repeating: 0, count: 258)
        for p in 0..<33 { f[p * 4] = 2; f[p * 4 + 1] = 4; f[p * 4 + 2] = 6; f[p * 4 + 3] = 0.7 }
        for p in [11, 12] { f[p * 4 + 1] = 6 }
        f[195] = 4; f[196] = 8; f[197] = 10
        let n = try FeatureNormalizer.normalize(f, poseSeen: true)
        try require(n[0] == 0 && n[1] == 0 && n[2] == 0 && n[3] == 0.7, "midhip/visibility")
        try require(n[45] == 1 && n[195] == 1 && n[196] == 2 && n[197] == 2, "torso/hand scale")
        try require(n[132..<195].allSatisfy { $0 == 0 }, "absent hand stays zero")
        try require(try FeatureNormalizer.normalize(f, poseSeen: false) == f, "pose unseen passthrough")
        let zeros = [Float](repeating: 0, count: 258)
        try require(try FeatureNormalizer.normalize(zeros, poseSeen: true) == zeros, "degenerate torso fallback")
    }
    static func identity() throws {
        let f = [Float](repeating: 0, count: 258)
        let seq = [[Float]](repeating: f, count: 30)
        let report = try FeedbackEngine.compare(learner: seq, gold: seq, targetLabel: "HELLO")
        try require(report.targetLabel == "HELLO" && report.overallMatch == 1 && report.items.isEmpty, "zero identity / DTW diagonal ties")
    }
    static func motion() throws {
        let gold = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        var learner = gold
        for t in 0..<30 { learner[t][64] = 0.4; learner[t][65] = 0.4 }
        let report = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "MOVE")
        try require(report.items.count == 1, "motion item emitted")
        let item = report.items[0]
        try require(item.dimension == "motion" && item.hand == "right" && item.severity == 0.707 && report.overallMatch == 0.293, "motion score and rounded overall")
        try require(item.prompt == "Move your right hand left and higher.", "motion prompt")
        for t in 0..<30 { learner[t][60] = 0.4; learner[t][61] = 0.4 }
        let tied = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "TIE")
        try require(tied.items.first?.hand == "right" && tied.items.first?.severity == 1, "equal motion picks right")
    }
    static func timing() throws {
        var gold = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        var learner = gold
        for t in 0..<30 { gold[t][60] = Float(t) * 0.02; learner[t][60] = Float(min(t * 3, 29)) * 0.02 }
        let report = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "FAST")
        try require(report.items.count == 1 && report.items[0].dimension == "timing" && report.items[0].severity == 1 && report.overallMatch == 0, "compressed trajectory timing")
        try require(report.items[0].prompt == "Your sign is faster than the model — take your time.", "timing prompt")
        let ties = FeedbackEngine.dtwPath([[0], [0], [0]], [[0], [0], [0]])
        try require(ties.count == 3 && ties.enumerated().allSatisfy { $0.offset == $0.element.0 && $0.offset == $0.element.1 }, "DTW diagonal first ties")
    }
    static func hands() -> [[Float]] {
        var seq = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        for t in 0..<30 { for base in [132, 195] {
            seq[t][base] = 0.1
            for i in 1..<21 { seq[t][base + i * 3] = Float(i) * 0.01 + 0.1; seq[t][base + i * 3 + 1] = Float((i + 1) % 4) * 0.02 }
        } }
        return seq
    }
    static func missingHands() throws {
        let gold = hands()
        let learner = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        let report = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "BOTH")
        try require(report.items.count == 2 && report.overallMatch == 0, "missing hands penalized")
        try require(report.items.map { $0.hand } == ["left", "right"], "stable hand order")
        for item in report.items {
            try require(item.dimension == "handshape" && item.severity == 1 && item.prompt == "This sign uses your \(item.hand) hand — keep it visible to the camera.", "missing hand prompt")
        }
    }
    static func planarHands() -> [[Float]] {
        var seq = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        for t in 0..<30 { for base in [132, 195] {
            seq[t][base] = 1
            for i in 1..<21 { seq[t][base + i * 3] = 2 }
            seq[t][base + 5 * 3 + 1] = 1
            seq[t][base + 17 * 3 + 1] = -1
        } }
        return seq
    }
    static func alteredHandshape() throws {
        let gold = planarHands()
        var learner = gold
        for t in 0..<30 { for i in 1..<21 { learner[t][132 + i * 3 + 2] = 1 } }
        let report = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "SHAPE")
        let shape = report.items.filter { $0.dimension == "handshape" }
        try require(shape.count == 1 && shape[0].severity == 1 && shape[0].hand == "left", "altered hand shape")
        try require(shape[0].prompt == "Check your left-hand shape — adjust your thumb and index fingers.", "finger stable tie and plural")
        learner = gold
        for t in 0..<30 { for i in 1...4 { learner[t][195 + i * 3 + 2] = 0.15 } }
        let thumb = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "THUMB")
        try require(thumb.items.count == 1 && thumb.items[0].severity == 0.5 && thumb.items[0].prompt == "Check your right-hand shape — adjust your thumb finger.", "single finger worst score and singular")
        learner = gold
        for t in 0..<30 { for base in [132, 195] { for i in 0..<21 { learner[t][base + i * 3] += 1 } } }
        try require(try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "TRANSLATE").items.isEmpty, "hand translation invariance")
    }
    static func orientation() throws {
        let gold = planarHands()
        var learner = gold
        for t in 0..<30 { for i in 0..<21 { learner[t][132 + i * 3 + 1] *= -1 } }
        let report = try FeedbackEngine.compare(learner: learner, gold: gold, targetLabel: "ROTATE")
        try require(report.items.map { $0.dimension } == ["handshape", "orientation"], "equal severity shape then orientation")
        try require(report.items[1].severity == 1 && report.items[1].hand == "left" && report.items[1].prompt == "Rotate your left palm to match the model orientation.", "flipped normal")
        try require(try FeedbackEngine.compare(learner: gold, gold: gold, targetLabel: "IDENTITY").items.isEmpty, "planar identity")
        var degenerate = gold
        for t in 0..<30 { for k in 132..<258 { degenerate[t][k] = 1 } }
        let deg = try FeedbackEngine.compare(learner: degenerate, gold: degenerate, targetLabel: "DEGENERATE")
        try require(deg.items.count == 2 && deg.items.allSatisfy { $0.dimension == "orientation" && $0.severity == 1 }, "reference degenerate normal semantics preserved")
    }
    static func rejects(_ body: () throws -> Void, _ message: String) throws {
        var rejected = false
        do { try body() } catch { rejected = true }
        try require(rejected, message)
    }
    static func validation() throws {
        let valid = [[Float]](repeating: [Float](repeating: 0, count: 258), count: 30)
        for value: Float in [.nan, .infinity, -.infinity] {
            var bad = valid
            bad[0][0] = value
            try rejects({ _ = try FeedbackEngine.compare(learner: bad, gold: valid, targetLabel: "BAD") }, "nonfinite learner must throw")
            try rejects({ _ = try FeedbackEngine.compare(learner: valid, gold: bad, targetLabel: "BAD") }, "nonfinite gold must throw")
            for poseSeen in [true, false] {
                try rejects({ _ = try FeatureNormalizer.normalize(bad[0], poseSeen: poseSeen) }, "nonfinite normalizer must throw even unseen")
            }
        }
        for count in [0, 257, 259] {
            let bad = [Float](repeating: 0, count: count)
            try rejects({ _ = try FeatureNormalizer.normalize(bad, poseSeen: false) }, "normalizer shape")
        }
        var shapes: [[[Float]]] = [[], Array(valid.prefix(29)), valid + [valid[0]]]
        var badRow = valid; badRow[2].removeLast(); shapes.append(badRow)
        for bad in shapes {
            try rejects({ _ = try FeedbackEngine.compare(learner: bad, gold: valid, targetLabel: "BAD") }, "learner shape")
            try rejects({ _ = try FeedbackEngine.compare(learner: valid, gold: bad, targetLabel: "BAD") }, "gold shape")
        }
        var overflow = valid[0]
        overflow[44] = .greatestFiniteMagnitude; overflow[48] = .greatestFiniteMagnitude
        try rejects({ _ = try FeatureNormalizer.normalize(overflow, poseSeen: true) }, "normalizer finite arithmetic overflow")
    }
    static let cases: [(String, () throws -> Void)] = [("normalization", normalization), ("identity", identity), ("motion", motion), ("timing", timing), ("missingHands", missingHands), ("alteredHandshape", alteredHandshape), ("orientation", orientation), ("validation", validation)]
}
#if HOST_CHECK
@main enum MathHost {
    static func main() {
        var failures = 0
        for (name, check) in MathChecks.cases {
            do { try check(); print("PASS \(name)") }
            catch { failures += 1; print("FAIL \(name): \(error)") }
        }
        print("\(MathChecks.cases.count) cases; \(failures) failures")
        if failures > 0 { exit(1) }
    }
}
#else
final class MathTests: XCTestCase {
    func testMathCases() throws { for (_, check) in MathChecks.cases { try check() } }
}
#endif
