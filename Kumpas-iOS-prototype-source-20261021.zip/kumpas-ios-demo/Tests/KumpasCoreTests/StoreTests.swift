import Foundation
#if !STORE_HOST_TEST
import XCTest
@testable import KumpasCore
#endif

private enum StoreCheck: Error, CustomStringConvertible {
    case failed(String)
    var description: String { switch self { case .failed(let message): return message } }
}

private func check(_ condition: @autoclosure () throws -> Bool, _ message: String) throws {
    if try !condition() { throw StoreCheck.failed(message) }
}

private func isolated(_ body: (URL) throws -> Void) throws {
    // Never consult default application, preferences, or participant directories.
    let base = URL(fileURLWithPath: ProcessInfo.processInfo.environment["TMPDIR"]!)
        .appendingPathComponent("kumpas-store-test-\(UUID().uuidString)", isDirectory: true)
    try FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: base) }
    try body(base.appendingPathComponent("injected", isDirectory: true))
}

private func identityAndSessions() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let id = try store.participantID()
        try check(UUID(uuidString: id) != nil, "participant is a UUID")
        try check(try store.activeSession() == nil, "new store has no session")
        let first = try store.startSession()
        let reopened = try PrototypeStore(directory: directory)
        try check(try reopened.participantID() == id, "identity survives reopen")
        try check(try reopened.activeSession() == first, "session survives reopen")
        let second = try reopened.startSession()
        try check(second != first, "starting closes and replaces the prior session")
        try reopened.endSession()
        try reopened.endSession()
        try check(try reopened.activeSession() == nil, "end clears active session")
        let ended = try PrototypeStore(directory: directory)
        try check(try ended.activeSession() == nil, "ended session stays ended on reopen")
    }
}

private func attempt(_ id: String? = nil) -> [String: Any] {
    var payload: [String: Any] = [
        "targetClass": 1, "targetLabel": "AKO", "predictedLabel": "AKO",
        "predictedConfidence": 0.9, "recognizedAsTarget": true, "overallMatch": 0.8,
        "items": [["dimension": "location", "severity": 0.2, "hand": "left", "prompt": "Itaas"]]
    ]
    if let id { payload["attemptId"] = id }
    return payload
}

private func attemptsPersist() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let before = Int64(Date().timeIntervalSince1970 * 1000)
        try store.appendAttempt(attempt("first"))
        try check(try store.activeSession() != nil, "attempt auto-creates a session")
        var second = attempt("second")
        second["overallMatch"] = 0.4
        try store.appendAttempt(second)
        let reopened = try PrototypeStore(directory: directory)
        let history = try reopened.history()
        try check(history.count == 2, "both attempts durable before return")
        try check(history[0]["attemptId"] as? String == "second", "history newest first, stable for equal milliseconds")
        try check(history[1]["targetClass"] as? Int == 1, "targetClass remains integer")
        try check(history[1]["recognizedAsTarget"] as? Bool == true, "recognition remains boolean")
        try check(history[1]["overallMatch"] as? Double == 0.8, "match retained for profile stats")
        try check(history[1]["timestamp"] as? Int64 ?? 0 >= before, "timestamp is epoch milliseconds")
        let items = history[1]["items"] as? [[String: Any]]
        try check(items?.first?["prompt"] as? String == "Itaas", "feedback array remains object array")
        try check(items?.first?["severity"] as? Double == 0.2, "feedback severity preserved")
    }
}

private func rejects(_ message: String, _ operation: () throws -> Void) throws {
    do { try operation() }
    catch { return }
    throw StoreCheck.failed(message)
}

private func withBlockedDirectory(_ directory: URL, _ operation: () throws -> Void) throws {
    let backup = directory.appendingPathExtension("held")
    try FileManager.default.moveItem(at: directory, to: backup)
    do {
        try Data("not a directory".utf8).write(to: directory)
        try operation()
    } catch {
        try? FileManager.default.removeItem(at: directory)
        try FileManager.default.moveItem(at: backup, to: directory)
        throw error
    }
    try FileManager.default.removeItem(at: directory)
    try FileManager.default.moveItem(at: backup, to: directory)
}

private func failedSaveCanRetry() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let identity = try store.participantID()
        try withBlockedDirectory(directory) {
            try rejects("failed attempt must not acknowledge success") { try store.appendAttempt(attempt("retry")) }
            try check(try store.history().isEmpty, "failed write must not enter memory history")
            try check(try store.activeSession() == nil, "failed auto-session must not enter memory")
            try rejects("start must propagate persistence failure") { _ = try store.startSession() }
            try check(try store.activeSession() == nil, "failed explicit session not visible")
        }
        try store.appendAttempt(attempt("retry"))
        let reopened = try PrototypeStore(directory: directory)
        try check(try reopened.history().count == 1, "retry saves exactly once")
        try check(try reopened.participantID() == identity, "failed writes preserve durable identity")
    }
}

private func duplicateIDs() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        try store.appendAttempt(attempt("same-id"))
        try store.endSession()
        let reopened = try PrototypeStore(directory: directory)
        try reopened.appendAttempt(attempt("same-id"))
        try check(try reopened.history().count == 1, "identical attemptId retry is idempotent across reopen")
        try check(try reopened.activeSession() == nil, "duplicate must not create a new session")
        var conflict = attempt("same-id")
        conflict["overallMatch"] = 0.1
        try rejects("conflicting reuse of attemptId must throw") { try reopened.appendAttempt(conflict) }
        try reopened.appendAttempt(attempt())
        try reopened.appendAttempt(attempt())
        try check(try reopened.history().count == 3, "missing IDs are independent attempts, not deduplicated")
    }
}

private func invalidAttempts() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        for value in [Double.nan, Double.infinity, -Double.infinity] {
            var invalid = attempt()
            invalid["overallMatch"] = value
            try rejects("nonfinite score rejected") { try store.appendAttempt(invalid) }
        }
        var nested = attempt()
        nested["items"] = [["dimension": "x", "severity": Double.nan, "hand": "left", "prompt": "x"]]
        try rejects("nested nonfinite number rejected") { try store.appendAttempt(nested) }
        var extra = attempt()
        extra["unparsedExtra"] = Double.infinity
        try rejects("nonfinite even in unknown fields rejected") { try store.appendAttempt(extra) }
        var malformed = attempt()
        malformed.removeValue(forKey: "targetClass")
        try rejects("missing required field rejected") { try store.appendAttempt(malformed) }
        malformed = attempt()
        malformed["recognizedAsTarget"] = "true"
        try rejects("wrong boolean type rejected") { try store.appendAttempt(malformed) }
        malformed = attempt()
        malformed["items"] = "[]"
        try rejects("stringified items rejected") { try store.appendAttempt(malformed) }
        malformed = attempt()
        malformed["extra"] = Date()
        try rejects("non-JSON value rejected") { try store.appendAttempt(malformed) }
        try check(try store.history().isEmpty, "invalid attempts leave no records")
        try check(try store.activeSession() == nil, "validation occurs before auto-session")
    }
}

private func assessmentPersistence() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let pre = "{\"fslConfidence\":2,\"synthetic\":true}"
        let post = "{\"fslConfidence\":5,\"sus\":[1,2,3]}"
        try store.saveAssessment(type: "pre", responses: pre)
        try store.saveAssessment(type: "post", responses: post)
        let reopened = try PrototypeStore(directory: directory)
        let rows = try reopened.assessments()
        try check(rows.count == 2, "assessments survive reopen")
        try check(rows[0]["type"] as? String == "pre", "assessment order oldest first")
        try check(rows[1]["responses"] as? String == post, "responses remains original JSON string, not object")
        try check(rows[0]["responses"] as? String == pre, "response bytes preserved")
        try check(rows[0]["participant_id"] as? String == reopened.participantID(), "assessment participant key matches Android")
        try check(rows[0]["timestamp"] as? Int64 ?? 0 > 1_000_000_000_000, "assessment timestamp milliseconds")
        try check(rows[0]["id"] as? Int == 1, "assessment id stays integer")
        for invalid in ["not-json", "[]", "{\"score\":NaN}", "{\"score\":1e999}"] {
            try rejects("invalid assessment responses rejected") { try reopened.saveAssessment(type: "pre", responses: invalid) }
        }
        try rejects("unknown assessment type rejected") { try reopened.saveAssessment(type: "other", responses: "{}") }
        try check(try reopened.assessments().count == 2, "rejected assessments never persisted")
    }
}

private func exportReadback() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        try store.appendAttempt(attempt("export-attempt"))
        try store.saveAssessment(type: "pre", responses: "{\"synthetic\":true}")
        try store.endSession()
        let firstPath = try store.exportData()
        let firstURL = URL(fileURLWithPath: firstPath)
        try check(firstURL.deletingLastPathComponent().standardizedFileURL == directory.standardizedFileURL,
                  "export scoped to injected directory")
        let bytes = try Data(contentsOf: firstURL)
        let root = try JSONSerialization.jsonObject(with: bytes) as! [String: Any]
        let metadata = root["metadata"] as! [String: Any]
        try check(metadata["participant_id"] as? String == store.participantID(), "export identity readback")
        try check(metadata["prototype"] as? Bool == true, "export identifies prototype scope")
        let sessions = root["sessions"] as! [[String: Any]]
        try check(sessions.count == 1, "export includes session")
        try check(sessions[0]["ended_at"] as? Int64 != nil, "export includes end timestamp")
        let attempts = sessions[0]["attempts"] as! [[String: Any]]
        try check(attempts.count == 1, "export nests attempts")
        try check(attempts[0]["targetLabel"] as? String == "AKO", "export preserves Dart attempt keys")
        let rows = root["assessments"] as! [[String: Any]]
        try check(rows.first?["responses"] as? String == "{\"synthetic\":true}", "export assessment string encoding")
        let summary = root["summary"] as! [String: Any]
        try check(summary["total_attempts"] as? Int == 1, "export summary from actual records")
        let second = try PrototypeStore(directory: directory).exportData()
        try check(firstPath != second, "unique exports across reopen")
        try check(try Data(contentsOf: firstURL) == bytes, "later export never overwrites earlier export")
        let stem = firstURL.deletingPathExtension().lastPathComponent
        try check(UUID(uuidString: String(stem.dropFirst("kumpas-prototype-export-".count))) != nil,
                  "export has scoped UUID filename")
    }
}

private func scopedPurge() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let oldID = try store.participantID()
        try store.appendAttempt(attempt("purge-me"))
        try store.saveAssessment(type: "post", responses: "{}")
        let export = try store.exportData()
        let reopened = try PrototypeStore(directory: directory)
        let sentinel = directory.appendingPathComponent("unrelated-sentinel.txt")
        let exportLikeSentinel = directory.appendingPathComponent("kumpas-prototype-export-\(UUID().uuidString).json")
        let outside = directory.deletingLastPathComponent().appendingPathComponent("outside-sentinel.txt")
        for url in [sentinel, exportLikeSentinel, outside] { try Data("keep".utf8).write(to: url) }
        try reopened.clearAllData()
        try check(!FileManager.default.fileExists(atPath: export), "managed exports removed across reopen")
        for url in [sentinel, exportLikeSentinel, outside] {
            try check(try Data(contentsOf: url) == Data("keep".utf8), "unrelated sentinel preserved: \(url.lastPathComponent)")
        }
        let fresh = try PrototypeStore(directory: directory)
        let freshID = try fresh.participantID()
        try check(freshID != oldID, "clear rotates persistent identity")
        try check(try fresh.history().isEmpty, "clear removes attempts")
        try check(try fresh.assessments().isEmpty, "clear removes assessments")
        try check(try fresh.activeSession() == nil, "clear removes active session")
        let emptyExport = try fresh.exportData()
        let root = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: emptyExport))) as! [String: Any]
        try check((root["sessions"] as? [Any])?.isEmpty == true, "clear removes historical sessions too")
        try fresh.appendAttempt(attempt("purge-me"))
        try check(try PrototypeStore(directory: directory).history().count == 1, "new identity can save and reopen after clear")
        try fresh.clearAllData()
        try check(!FileManager.default.fileExists(atPath: emptyExport), "subsequent exports remain managed")
    }
}

private func corruptStoreIsNotReset() throws {
    try isolated { directory in
        _ = try PrototypeStore(directory: directory)
        let snapshot = directory.appendingPathComponent("prototype-store.json")
        let invalid = Data("broken-json".utf8)
        try invalid.write(to: snapshot)
        try rejects("corrupt snapshot throws rather than silently replacing identity") { _ = try PrototypeStore(directory: directory) }
        try check(try Data(contentsOf: snapshot) == invalid, "corrupt snapshot preserved for diagnosis")
    }
}

private func otherWriteFailuresCanRetry() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        try store.appendAttempt(attempt("kept"))
        let session = try store.activeSession()
        let identity = try store.participantID()
        try withBlockedDirectory(directory) {
            try rejects("end propagates save failure") { try store.endSession() }
            try check(try store.activeSession() == session, "failed end retains active session for retry")
            try rejects("assessment propagates save failure") { try store.saveAssessment(type: "pre", responses: "{}") }
            try check(try store.assessments().isEmpty, "failed assessment not visible")
            try rejects("export propagates save failure") { _ = try store.exportData() }
            try rejects("clear propagates save failure") { try store.clearAllData() }
            try check(try store.participantID() == identity, "failed clear does not rotate memory identity")
            try check(try store.history().count == 1, "failed clear does not reset memory history")
        }
        try store.endSession()
        try store.saveAssessment(type: "pre", responses: "{}")
        let export = try store.exportData()
        try check(FileManager.default.fileExists(atPath: export), "export retry publishes file")
        let reopened = try PrototypeStore(directory: directory)
        try check(try reopened.activeSession() == nil, "end retry durable")
        try check(try reopened.assessments().count == 1, "assessment retry durable once")
        try reopened.clearAllData()
        try check(try PrototypeStore(directory: directory).history().isEmpty, "clear retry durable")
    }
}

private func purgeUnexpectedDirectoryCanRetry() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let id = try store.participantID()
        let exportURL = URL(fileURLWithPath: try store.exportData())
        try FileManager.default.removeItem(at: exportURL)
        try FileManager.default.createDirectory(at: exportURL, withIntermediateDirectories: false)
        let sentinel = exportURL.appendingPathComponent("keep.txt")
        try Data("keep".utf8).write(to: sentinel)
        try rejects("purge must not recurse into an unexpected directory") { try store.clearAllData() }
        try check(try Data(contentsOf: sentinel) == Data("keep".utf8), "directory sentinel survives failed purge")
        try check(try store.participantID() == id, "failed purge retains identity")
        try FileManager.default.removeItem(at: exportURL)
        try store.clearAllData()
        try check(try PrototypeStore(directory: directory).participantID() != id, "purge retry succeeds")
    }
}

private func purgeDanglingExportLink() throws {
    try isolated { directory in
        let store = try PrototypeStore(directory: directory)
        let path = try store.exportData()
        try FileManager.default.removeItem(atPath: path)
        let missing = directory.appendingPathComponent("missing-target")
        try FileManager.default.createSymbolicLink(atPath: path, withDestinationPath: missing.path)
        try store.clearAllData()
        let link = try? FileManager.default.destinationOfSymbolicLink(atPath: path)
        try check(link == nil, "managed dangling symlink must be removed, not orphaned")
        try check(!FileManager.default.fileExists(atPath: missing.path), "purge never creates or touches link target")
    }
}

private let storeCases: [(String, () throws -> Void)] = [
    ("identity and session persistence", identityAndSessions),
    ("attempt persistence and Dart history shape", attemptsPersist),
    ("failed save and retry without permissions", failedSaveCanRetry),
    ("duplicate attempt IDs", duplicateIDs),
    ("malformed and nonfinite JSON rejection", invalidAttempts),
    ("assessment persistence and string payload", assessmentPersistence),
    ("scoped export readback and uniqueness", exportReadback),
    ("scoped purge, identity rotation and reopen", scopedPurge),
    ("corrupt store fails closed", corruptStoreIsNotReset),
    ("end, assessment, export and clear failure retries", otherWriteFailuresCanRetry),
    ("purge refuses unexpected directory and retries", purgeUnexpectedDirectoryCanRetry),
    ("purge removes dangling managed export link", purgeDanglingExportLink)
]

#if STORE_HOST_TEST
@main
private enum StoreHostTests {
    static func main() {
        var failures = 0
        for (name, test) in storeCases {
            do { try test(); print("PASS: \(name)") }
            catch { failures += 1; print("FAIL: \(name): \(error)") }
        }
        print("Store host checks: \(storeCases.count - failures)/\(storeCases.count) passed")
        if failures != 0 { exit(1) }
    }
}
#else
final class StoreTests: XCTestCase {
    func testStoreBehaviors() throws {
        for (name, test) in storeCases {
            do { try test() }
            catch { XCTFail("\(name): \(error)") }
        }
    }
}
#endif
